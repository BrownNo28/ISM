# [ Imported Python packages ]
import os
import sys
import pandas as pd

from topsegi.variable import *
#======================================================================= 
def message_segmentation(message): #minkyu ok
	
	# >> global, int, intention(in)
	n_separator = get_n_separator()
	
	# >> local, str, intention(in)
	# >  message
	
	print("\u276F" * n_separator + "\n")
	print(f"\u2726 {message} \u2726" +"\n")
#======================================================================= 
# { SYSTEM : Exception Handling }
def handle_exception(value, switch="on"): #minkyu ok
    
	# Exception Handling Function
	
	# >> global, str, intention(in)
	# > get_interface()
	
	# >> local, str, intention(in)
	# >  value
	
	print(f"\u2714 Invalid input: [{value}]. Enter a correct value.")
	print("\n")
	
	if switch == "on" and get_interface() == "i":
		sys.exit()
#======================================================================= 
def enter_path_input_card(): #minkyu ok
	
	# >> global, str, intention(inout)
	# >  instance_system.path_input_card
	
	# >> global, Dataframe, intention(inout)
	# >  instance_system.input_card_data
	
	# >> local, str, intention(out)
	# >  path_relative
	# >  confirm
	
	while True:
		
		try:
			set_path_input_card(
			str(input("\u21E8 Enter the file path of the input card : "))
			)
			
			# Confirm the entered path_input_card
			path_relative = os.path.relpath(get_path_input_card())
			set_path_input_card(path_relative)
			
			confirm = str(input(f"\u21E8 You entered [{path_relative}]. Is this correct? (yes=1 or no=0): "))
			
			# Folder name confirmation
			if confirm == "1":
				
				set_data_input_card(
				pd.read_csv(get_path_input_card(), sep=",", header=None, index_col=0)
				)
				
				print("\u2714 Check [Data of input card] : ", get_path_input_card())
				
				for i in range(len(get_data_input_card())):
					print("\u21E2 "+str(get_data_input_card().index[i]) + " : " + str(get_data_input_card().iloc[i,0]))
				print("\n")
				break
				
			else:
				handle_exception(get_path_input_card(), switch="off")
			
		except ValueError:
			handle_exception(get_path_input_card(), switch="off")
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
def enter_interface(): #minkyu ok
	
	# Description : Interface Setting
	
	# >> global, str, intention(inout)
	# >  get_interface()

	# >> global, str, intention(in)
	# >  set_interface()
	
	while True:
		
		try:
			set_interface(
			str(input("\u21E8 Enter the interface to use (c or i) \n" \
			"  [c = Command Line Interface, i = Input Card] : "))
			)
			
			if get_interface() == "c":
				print("\u2714 Starting [Command Line Interface] mode.")
				print("\n")
				break
				
			elif get_interface() == "i":
				print("\u2714 Starting [Input Card] mode.")
				print("\n")
				
				enter_path_input_card()
				break
				
			else:
				handle_exception(get_interface(), switch="off")
		
		except ValueError:
			handle_exception(get_interface(), switch="off")
#=======================================================================
def enter_name_folder(path_base, tag_folder, name_interface_i_col):
	
	print(f"\u21E2 The location where the [{tag_folder}] will be created : {path_base}")
	print("\n")
	
	if get_interface() == "c":
	
		while True:
			
			try:

				# Get the folder name
				name_folder = str(input(f"\u21E8 Enter the name for the [{tag_folder}] storage folder to be created : "))
				print("\n")
				
				# Confirm the entered folder name
				confirm = input(f"\u21E8 You entered '[{name_folder}]'. Is this correct? (yes=1 or no=0): ")
				
				# Folder name confirmation
				if confirm == "1":
					print(f"\u2714 [{tag_folder}] confirmed : {name_folder}")
					print("\n")
					break
					
				else:
					handle_exception(name_folder)
					
			except ValueError:
				handle_exception(name_folder)
				
	if get_interface() == "i":
		
		while True:
			
			try:
				name_folder = get_data_input_card().loc[name_interface_i_col].iloc[0]
				break
		
			except ValueError:
				handle_exception(name_folder)
				
	return name_folder
#$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
#=======================================================================
def while_try_mol_num(mol_num=None):
	
	while True:
	
		try:
			if mol_num is None:  # mol_num가 없으면 사용자 입력 받기
				mol_num = int(input("\u21E8 Enter the number of the molecular structure to be calculated [0~9] : "))
				set_mol_num(mol_num)
			
			if 0 <= mol_num <= 9:
				print("\u2714 [ "+get_molecule_structure()[mol_num][1]+" ] molecule structure selected." + "\n")
				print("\n")
				break
			
			else:
				handle_exception(mol_num)  # 잘못된 입력 처리
				mol_num = None  # 잘못된 입력 후 mol_num를 초기화
		
		except ValueError:
			handle_exception(mol_num)
			mol_num = None  # 잘못된 입력 후 mol_num를 초기화
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
def while_try_parity(parity=None):
	
	while True:
	
		try:
			if parity is None:  # parity가 없으면 사용자 입력 받기
				parity = int( input("\u21E8 Enter the parity (even = 0, odd = 1) : ") )
				temporary = get_molecule_structure()
				temporary[get_mol_num()][3][0] = parity
				set_molecule_structure(temporary)
				
			if parity == 0 or parity == 1:
				print("\u2714 [ "+get_symmetrical_properties()[parity]+" ] symmetrical properties selected.")
				print("\n")
				break
			
			else:
				handle_exception(parity)  # 잘못된 입력 처리
				parity = None  # 잘못된 입력 후 parity를 초기화
		
		except ValueError:
			handle_exception(parity)
			parity = None  # 잘못된 입력 후 parity를 초기화
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
def enter_theo():
	
	for i in range(len(get_molecule_structure())):
		print("\u2605 " + get_molecule_structure()[i][1] + ", " + get_molecule_structure()[i][2])
	print("\n")
	
	if get_interface() == "c":
		while_try_mol_num()  # 사용자 입력 받기
		
		if get_molecule_structure()[get_mol_num()][2] == "symmetric":
			while_try_parity()
	
	elif get_interface() == "i":
		set_mol_num(
		int(get_data_input_card().loc["mol_num"].iloc[0])
		)
		while_try_mol_num(get_mol_num())  # 전달된 instance_system.mol_num 값으로 처리
		
		if get_molecule_structure()[get_mol_num()][2] == "symmetric":
			temporary = get_molecule_structure()
			temporary[get_mol_num()][3][0] = int(get_data_input_card().loc["symmetrical_properties"].iloc[0])
			set_molecule_structure(temporary)
			while_try_parity(temporary[get_mol_num()][3][0]) # 전달된 get_molecule_structure()[get_mol_num()][3][0] 값으로 처리
			
#-----------------------------------------------------------------------
	# minkyu
	if get_molecule_structure()[get_mol_num()][3][0] == 0: # symmetric(even) = 0
		set_astronomer_convention( get_molecule_structure()[get_mol_num()][4][0] )
		set_str_astronomer_convention( get_molecule_structure()[get_mol_num()][5][0] )
		
	elif get_molecule_structure()[get_mol_num()][3][0] == 1: # symmetric(odd) = 1
		set_astronomer_convention( get_molecule_structure()[get_mol_num()][4][1] )
		set_str_astronomer_convention( get_molecule_structure()[get_mol_num()][5][1] )
	
	elif get_molecule_structure()[get_mol_num()][3][0] == 2: # asymmetric = 2
		set_astronomer_convention( 1. )
		set_str_astronomer_convention( "1" )

	# [ Set Astronomer convention ]
	print("\u2756 Set Astronomer convention \u2756")
	print("\n")
	
	print(f"\u21E2 Astronomer convention : {get_str_astronomer_convention()}")
	print("\n")

#-----------------------------------------------------------------------
		
	# [ set theoretical data path ]
	print("\u2756 Set theoretical data path \u2756")
	print("\n")
	
	path_TIPS_array = pd.read_csv("../input/theoretical_data/path_TIPS.csv", sep=",", header=None, index_col=0)
	path_rotational_branches_array = pd.read_csv("../input/theoretical_data/path_Rotational_Branches.csv", sep=",", header=None, index_col=0)

	# TIPS_file_path
	path_TIPS = os.path.relpath(path_TIPS_array.iloc[get_mol_num(),0])
	print("\u21E2 TIPS(Total Internal Partition Sums) data file path")
	print(path_TIPS)
	print("\n")
	
	# rotational_branches_file_path
	path_RB = os.path.relpath(path_rotational_branches_array.iloc[get_mol_num(),0])
	print("\u21E2 Rotational_Branches data file path")
	print(path_RB)
	print("\n")

	return path_TIPS, path_RB
#=======================================================================
def enter_TIPS(path_file): #def_ok
	
	# TIPS
	
	# file_type : csv
	# file_sep : ,
	# file_columns : [T, Q], T=[K], Q=[], header!=None
	
	# get_file_name
	name_file = os.path.basename(path_file)
	
	# get_data
	TIPS = pd.read_csv(path_file, sep=",")
	
	# get TIPS min and max
	set_min_TIPS(TIPS["Q"].min())
	set_max_TIPS(TIPS["Q"].max())
	
	# print data
	print("\u2714 Check Table : ", path_file)
	print(TIPS)
	print("\n")
	
	return name_file, TIPS
#=======================================================================
def enter_RB(path_file): #def_ok
	
	# RB = rotational_branches
	
	# get_name_file
	name_file = os.path.basename(path_file)
	
	# get_data
	RB = pd.read_csv(path_file, sep=",")

	# print data
	print("\u2714 Check Table : ", path_file)
	print(RB)
	print("\n")
	
	return name_file, RB
#=======================================================================
#=======================================================================
#=======================================================================

def while_try_path_obs_confirm(path_obs_confirm=None):
	
	while True:
	
		try:
			if path_obs_confirm is None:  # path_obs_confirm가 없으면 사용자 입력 받기
				path_obs = str(input("\u21E8 Enter the file path of the observational data : "))
				print("\n")
				
				path_relative = os.path.relpath(path_obs)
				path_obs_confirm = str(input(f"\u21E8 You entered [{path_relative}]. Is this correct? (yes=1 or no=0): "))
				
			if path_obs_confirm == "1":
				
				path_relative = os.path.relpath(path_obs)
				print(f"\u21E2 Observational data file path : {path_relative}")
				
				set_path_obs(path_relative)
				set_name_obs_data(os.path.basename(path_relative))
				
				return True  # @@@ 루프 종료 시 상위 함수로 True 반환 @@@
				

			else:
				handle_exception(path_obs_confirm)  # 잘못된 입력 처리
				path_obs_confirm = None  # 잘못된 입력 후 path_obs_confirm를 초기화
		
		except ValueError:
			handle_exception(path_obs_confirm)
			path_obs_confirm = None  # 잘못된 입력 후 path_obs_confirm를 초기화

def while_try_obs_switch(obs_switch=None):
	
	while True:
	
		try:
			if obs_switch is None:  # obs_switch가 없으면 사용자 입력 받기
				obs_switch = str( input("\u21E8 Do you have observational data? (yes = 1, no = 0) : ") )
				print("\n")
				
			if obs_switch == "1":				
				while_try_path_obs_confirm()
				return True  # @@@ 루프 종료 시 상위 함수로 True 반환 @@@
				
			elif obs_switch == "0":
				print("╔═════════════════════════════════════════════════════════════╗")
				print("║                        END PROGRAM                          ║")
				print("╚═════════════════════════════════════════════════════════════╝")
				sys.exit()
			
			else:
				handle_exception(obs_switch)  # 잘못된 입력 처리
				obs_switch = None  # 잘못된 입력 후 obs_switch를 초기화
		
		except ValueError:
			handle_exception(obs_switch)
			obs_switch = None  # 잘못된 입력 후 obs_switch를 초기화	

def enter_path_obs():
	
	if get_interface() == "c":
		while_try_obs_switch()
	
	elif get_interface() == "i":
		
		if int(get_data_input_card().loc["obs_switch"].iloc[0]) == 0:
			print("╔═════════════════════════════════════════════════════════════╗")
			print("║                        END PROGRAM                          ║")
			print("╚═════════════════════════════════════════════════════════════╝")
			sys.exit()
		
		elif int(get_data_input_card().loc["obs_switch"].iloc[0]) == 1:
			
			path_obs = str(get_data_input_card().loc["obs_path"].iloc[0])
			path_relative = os.path.relpath(path_obs)
			print(f"\u21E2 Observational data file path : {path_relative}")
			
			set_path_obs(path_relative)
			set_name_obs_data(os.path.basename(path_relative))

