import numpy as np
import pandas as pd
from scipy.stats import chi2, norm

from topsegi.variable import *
from topsegi.data import *
#=======================================================================
def cal_RB(RB):
	
	# convert_J_to_cm_inverse
	
	# J에서 cm^-1 단위 변환
	# E [J] = h[J*s]*c[m/s]*tilde_nu[m^-1]
	# tilde_nu[m^-1] = E/(h*c)

	# Planck constant
	h = 6.62607015e-34 #[J*s]
	
	# Speed of light
	c = 2.99792458e8 #[m/s]
	
	# Boltzmann constant
	kb = 1.380649e-23 #[J*K^-1]

	# (kb) J에서 cm^-1 단위 변환
	kb_cminv = kb
	
	# E[J] -> E[m^-1]
	kb_cminv = kb_cminv/(h*c)
	
	# E[m^-1] -> E[cm^-1]
	kb_cminv = kb_cminv/100.0	
	
	# set E_l/k_b
	RB["E_l/k_b"] = RB["E_l"].copy()/kb_cminv
	
	return RB
#=======================================================================
# 선형 보간
def cal_linear_interpolation_TIPS(TIPS, user_T): # input_data_Q -> TIPS
	
	# used linear interpolation function
	if(user_T == int(user_T)):
		
		linear_interpolation_TIPS = TIPS.loc[TIPS["T"] == user_T, "Q"].values
		linear_interpolation_TIPS = linear_interpolation_TIPS[0]
		
	else:

		key=float(int(user_T))
		TIPS1 = TIPS.loc[TIPS["T"] == key, "Q"].values

		key=float(int(user_T + 1.))
		TIPS2 = TIPS.loc[TIPS["T"] == key, "Q"].values

		linear_interpolation_TIPS = TIPS1+(TIPS2-TIPS1)*(user_T-float(int(user_T)))
		linear_interpolation_TIPS = linear_interpolation_TIPS[0]
		
	return linear_interpolation_TIPS
#=======================================================================	
def cal_theo(sort_and_drop_RB, TIPS, user_T, tag_data="off"):
		
	Q = cal_linear_interpolation_TIPS(TIPS, user_T)
	Q = get_astronomer_convention() * Q
	
	g_l = sort_and_drop_RB["g_l"]
	E_l_k_b = sort_and_drop_RB["E_l/k_b"]
	N_N_l = (Q/g_l) * np.exp(E_l_k_b/user_T)
	
	# save data
	cal_theo_data = pd.DataFrame({})
	cal_theo_data["J_l"] = sort_and_drop_RB["J_l"]
	cal_theo_data["log10(N_N_l)"] = np.log10(N_N_l)
	
#-----------------------------------------------------------------------
	if tag_data=="off":
		name_data = str(get_molecule_structure()[get_mol_num()][1]) + "_" + \
					str(get_symmetrical_properties()[get_molecule_structure()[get_mol_num()][3][0]]) + "_" +\
					str(user_T)+"K_theo.csv"
		
	else:
		name_data = tag_data+"_"+str(get_molecule_structure()[get_mol_num()][1]) + "_" + \
					str(get_symmetrical_properties()[get_molecule_structure()[get_mol_num()][3][0]]) + "_" +\
					str(user_T)+"K_theo.csv"
					
	data_save(cal_theo_data, name_data)
	
	return cal_theo_data

### minkyu try
def cal_weighted_linear_regression(x, y, y_err_lower, y_err_upper):
    """
    Weighted linear regression to compute slope (a), intercept (b),
    and their errors (a_err, b_err) using a method similar to lmfit.
    """
    # 1. 가중치 계산
    avg_error = (y_err_lower + y_err_upper) / 2.0  # 평균 에러
    weights = 1.0 / (avg_error ** 2)  # lmfit 방식: 가중치 1/sigma^2

    # 2. 가중 평균 선형 회귀 수행
    A = np.vstack([x, np.ones(len(x))]).T
    W = np.diag(weights)  # 가중치 대각 행렬

    # A^T W A 및 A^T W y 계산
    ATW = np.dot(A.T, W)
    ATWA = np.dot(ATW, A)
    ATWy = np.dot(ATW, y)

    # 회귀 계수 계산
    ATWA_inv = np.linalg.inv(ATWA)
    params = np.dot(ATWA_inv, ATWy)
    a, b = params

    # 3. 잔차 계산 및 공분산 행렬 수정
    residuals = y - (a * x + b)
    reduced_chi_squared = np.sum(weights * residuals**2) / (len(y) - 2)  # 자유도 보정

    # 공분산 행렬에 reduced chi-squared 반영
    cov_matrix = ATWA_inv * reduced_chi_squared

    # 4. 오차 계산
    a_err = np.sqrt(cov_matrix[0, 0])  # 기울기 오차
    b_err = np.sqrt(cov_matrix[1, 1])  # 절편 오차
	
	#-------------------------------------------------------------------
	
    # # 결과 출력
    # print("a : ", a)
    # print("b : ", b)
    # print("a_err : ", a_err)
    # print("b_err : ", b_err)
    # print("\n")

    # # 변환 값 계산
    # linear_fit_T, linear_fit_T_error = get_linear_fit_T(a, a_err)
    # print(f"linear_fit_T : {linear_fit_T:.4E}")
    # print(f"linear_fit_T_error : {linear_fit_T_error:.4E}")
    # print("\n")

    return a, b, a_err, b_err
#-----------------------------------------------------------------------
def cal_weighted_linear_regression_T(a, a_err):
    """
    -1/a 변환에서의 오차를 계산

    Parameters:
    - a: float, 원래 기울기 값
    - a_err: float, 원래 기울기의 오차

    Returns:
    - transformed_value: float, 변환된 값 -1/a
    - transformed_error: float, 변환된 값의 오차
    """
    weighted_linear_regression_T = -1. / a
    weighted_linear_regression_T_error = a_err / abs(a ** 2)
    
    return weighted_linear_regression_T, weighted_linear_regression_T_error
#-----------------------------------------------------------------------
# 선형 함수 정의
def linear_func(x, a, b):
    return a * x + b
#-----------------------------------------------------------------------    
def cal_weighted_linear_regression_N(astronomer_convention, linear_interpolation_TIPS, b, b_err):
	
	weighted_linear_regression_N = astronomer_convention * linear_interpolation_TIPS * np.exp(b)
	
	weighted_linear_regression_N_error = weighted_linear_regression_N * b_err
	
	return weighted_linear_regression_N, weighted_linear_regression_N_error    
#----------------------------------------------------------------------- 

def cal_rotation_diagram(filtered_obs, TIPS):
	
	astronomer_convention = get_astronomer_convention()
	
	# convert input
	x = np.array(filtered_obs["E_l/k_b"].copy())
	y = np.array(filtered_obs["ln(N_l/g_l)"].copy())
	y_err_lower = np.array(filtered_obs["ln(N_l/g_l)_SD"].copy())  # y 데이터의 하한 에러
	y_err_upper = np.array(filtered_obs["ln(N_l/g_l)_SD"].copy())  # y 데이터의 상한 에러
	# Branch_P = filtered_obs[filtered_obs["Branch"] == "P"].copy()	
	# Branch_Q = filtered_obs[filtered_obs["Branch"] == "Q"].copy()
	# Branch_R = filtered_obs[filtered_obs["Branch"] == "R"].copy()
	
	a, b, a_err, b_err = cal_weighted_linear_regression(x, y, y_err_lower, y_err_upper)
	# print(f"a : {a:.4E}")
	# print(f"b : {b:.4E}")
	# print(f"a_err : {a_err:.4E}")
	# print(f"b_err : {b_err:.4E}")
	# print("\n")
	
	weighted_linear_regression_T, weighted_linear_regression_T_error = cal_weighted_linear_regression_T(a, a_err)
	# print(f"weighted_linear_regression_T : {weighted_linear_regression_T:.4E}")
	# print(f"weighted_linear_regression_T_error : {weighted_linear_regression_T_error:.4E}")
	# print("\n")
	
	linear_interpolation_TIPS = cal_linear_interpolation_TIPS(TIPS, weighted_linear_regression_T)
	# print(f"linear_interpolation_TIPS : {linear_interpolation_TIPS:.4E}")
	# print("\n")
	
	weighted_linear_regression_N, weighted_linear_regression_N_error = cal_weighted_linear_regression_N(astronomer_convention, linear_interpolation_TIPS, b, b_err)
	# print(f"weighted_linear_regression_N : {weighted_linear_regression_N:.4E}")
	# print(f"weighted_linear_regression_N_error : {weighted_linear_regression_N_error:.4E}")
	# print("\n")

	filtered_obs["log10(N/N_l)"] = np.log10(weighted_linear_regression_N/filtered_obs["N_l"])
	propa_1 = 1./np.log(10.)
	propa_2 = (weighted_linear_regression_N_error / weighted_linear_regression_N)**2
	propa_3 = (filtered_obs["N_l_SD"] / filtered_obs["N_l"])**2
	filtered_obs["log10(N/N_l)_SD"] = propa_1 * (propa_2+propa_3)**0.5
	# print("[TEST] filtered_obs")
	# print(filtered_obs)

	#-------------------------------------------------------------------
	WLR_x = np.linspace(min(x), max(x), 1000)
	WLR_y = linear_func(WLR_x, a, b)
	
	return (a, a_err, b, b_err, WLR_x, WLR_y, weighted_linear_regression_T, weighted_linear_regression_T_error, weighted_linear_regression_N, weighted_linear_regression_N_error)

def cal_parameter_range(x_m_evaluator, x_p_evaluator, y_m_evaluator, y_p_evaluator):

	# float, intention(in)
	min_TIPS = get_min_TIPS()
	max_TIPS = get_max_TIPS()
	
	# T_start
	if x_m_evaluator <= min_TIPS:
		T_start = min_TIPS
	elif x_m_evaluator > min_TIPS:
		T_start = x_m_evaluator
	
	# T_end
	if x_p_evaluator <= max_TIPS:
		T_end = x_p_evaluator
	elif x_p_evaluator > max_TIPS:
		T_end = max_TIPS
		
	# N_start
	if y_m_evaluator <= 0.:
		N_start = 0.
	elif y_m_evaluator  > 0.:
		N_start = y_m_evaluator
		
	# N_end (Extendable to infinity)
	N_end = y_p_evaluator
	
	return (T_start, T_end, N_start, N_end)

def convert_delta_chi2_to_sigma(delta_chi2, dof):

	# Survival function (1 - CDF) 사용
	sf = chi2.sf(delta_chi2, dof)  # 1 - CDF 값을 안정적으로 계산
	
	# σ 값 변환: norm.ppf(1 - sf / 2)와 동일한 계산
	sigma = -norm.ppf(sf / 2)
			
	return sigma

def cal_distinction_N_l(T, N, TIPS, filtered_theo, filtered_obs):
	
	# get interpolation_Q
	interpolation_Q = cal_linear_interpolation_TIPS(TIPS, T)
	interpolation_Q = get_astronomer_convention() * interpolation_Q
	
	# get_N_l_theo_array
	distinction_N_l = filtered_theo.copy()
	distinction_N_l["N_l_theo"] = (N * distinction_N_l["g_l"]/interpolation_Q)/np.exp(distinction_N_l["E_l/k_b"]/T)
	
	distinction_N_l["N_l_obs"] = np.array(filtered_obs["N_l"].copy())
	distinction_N_l["N_l_SD"] = np.array(filtered_obs["N_l_SD"].copy())
	#+++
	distinction_N_l["distinction"] = ( (distinction_N_l["N_l_obs"] - distinction_N_l["N_l_theo"])/distinction_N_l["N_l_SD"] )**2
	#print(distinction_N_l)
	
	#single_distinction = np.log10(distinction_N_l["distinction"].sum())
	single_distinction = distinction_N_l["distinction"].sum()
	
	return single_distinction
	
def cal_data_background_contour(T_start, T_end, N_start, N_end, axis_grid, TIPS, filtered_theo, filtered_obs):

	x = np.linspace(T_start, T_end, axis_grid)  # T 좌표 범위
	y = np.linspace(N_start, N_end, axis_grid)   # N 좌표 범위

	# 2차원 그리드 생성
	X, Y = np.meshgrid(x, y)     

#-----------------------------------------------------------------------
	# 그리드의 각 점에 대한 Z 값을 계산합니다.
	# Z 값을 직접 계산합니다.
	Z = np.zeros_like(X)  # X와 동일한 크기의 Z 배열 초기화

	# 각 (i, j) 위치에서 Z 값을 설정합니다.
	for i in range(X.shape[0]):
	    for j in range(X.shape[1]):
	        # 예: X[i, j]와 Y[i, j]의 합을 Z 값으로 설정
	        #Z[i, j] = X[i, j]**2 + Y[i, j]**2  # 또는 원하는 수식을 적용
	 
	        Z[i, j] = cal_distinction_N_l(X[i,j], Y[i,j], TIPS, filtered_theo, filtered_obs)
    
	# # 기존 스칼라 함수를 벡터화
	# vectorized_cal_distinction_N_l = np.vectorize(cal_distinction_N_l)
	
	# # 벡터화된 함수를 사용하여 Z 값을 계산
	# Z = vectorized_cal_distinction_N_l(X, Y, TIPS, filtered_theo, filtered_obs)
#-----------------------------------------------------------------------
	
	# Z에서 최소값과 2차원 인덱스 찾기
	min_index = np.unravel_index(np.argmin(Z), Z.shape)
	min_X = X[min_index]
	min_Y = Y[min_index]
	min_Z_chi2 = Z[min_index]
	
	Z_chi2 = Z
	
	# Z = Z-min_Z
	Z_del = Z_chi2 - min_Z_chi2
	
	# get sigma
	Z_sigma = convert_delta_chi2_to_sigma(Z_del, dof=2)
	
	
	return X, Y, Z_chi2, Z_sigma, min_X, min_Y, min_Z_chi2

#=======================================================================

def convert_sigma_to_delta_chi2(sigma, dof):
	# 수치적으로 안정적인 SF 값 계산
	sf = 2 * norm.sf(sigma)  # norm.sf = 1 - norm.cdf
	
	# Δχ² 값 계산 (Inverse SF)
	delta_chi2 = chi2.isf(sf, dof)
	
	return delta_chi2

def quadtree_search(x_min, x_max, y_min, y_max, TIPS, filtered_theo, filtered_obs, threshold, user_depth, add_depth, depth=0):
    mid_x = (x_min + x_max) / 2
    mid_y = (y_min + y_max) / 2
    #disc_value = get_distinction(mid_x, mid_y, a1, b1, a2, b2)
    disc_value = cal_distinction_N_l(mid_x, mid_y, TIPS, filtered_theo, filtered_obs)

    points = []
    rectangle_points = []
    if disc_value < threshold:
        points.append((mid_x, mid_y))
        rectangle_points.append((x_min, x_max, y_min, y_max))  # **노드 범위 추가**
        extra_depth = user_depth + add_depth
    else:
        rectangle_points.append((x_min, x_max, y_min, y_max))  # **노드 범위 추가**
        extra_depth = user_depth

    all_points = [(mid_x, mid_y, disc_value)]

    if depth < extra_depth:
        sub_points, sub_all_points, sub_points_rectangle = quadtree_search(x_min, mid_x, y_min, mid_y, TIPS, filtered_theo, filtered_obs, threshold, user_depth, add_depth, depth + 1)
        points.extend(sub_points)
        all_points.extend(sub_all_points)
        rectangle_points.extend(sub_points_rectangle)

        sub_points, sub_all_points, sub_points_rectangle = quadtree_search(mid_x, x_max, y_min, mid_y, TIPS, filtered_theo, filtered_obs, threshold, user_depth, add_depth, depth + 1)
        points.extend(sub_points)
        all_points.extend(sub_all_points)
        rectangle_points.extend(sub_points_rectangle)

        sub_points, sub_all_points, sub_points_rectangle = quadtree_search(x_min, mid_x, mid_y, y_max, TIPS, filtered_theo, filtered_obs, threshold, user_depth, add_depth, depth + 1)
        points.extend(sub_points)
        all_points.extend(sub_all_points)
        rectangle_points.extend(sub_points_rectangle)

        sub_points, sub_all_points, sub_points_rectangle = quadtree_search(mid_x, x_max, mid_y, y_max, TIPS, filtered_theo, filtered_obs, threshold, user_depth, add_depth, depth + 1)
        points.extend(sub_points)
        all_points.extend(sub_all_points)
        rectangle_points.extend(sub_points_rectangle)

    return points, all_points, rectangle_points

def quadtree_analyzer(TIPS, filtered_theo, filtered_obs, T_start, T_end, N_start, N_end, min_Z, user_threshold, input_user_depth, input_add_depth):
	
	delta_chi2 = convert_sigma_to_delta_chi2(user_threshold, dof=2)
	user_threshold = min_Z + delta_chi2
	
	points, all_points, rectangle_points = quadtree_search(T_start, T_end, N_start, N_end, TIPS, filtered_theo, filtered_obs, threshold=user_threshold, user_depth=input_user_depth, add_depth=input_add_depth) #try
	
	#pandas
	pd_points = pd.DataFrame({})
	pd_all_points = pd.DataFrame({})
	result_quadtree_analyzer = pd.DataFrame({})
	
	# points
	pd_points["T"] = np.array([point[0] for point in points])
	pd_points["N"] = np.array([point[1] for point in points])	

	# all_points
	pd_all_points["T"] = np.array([point[0] for point in all_points])
	pd_all_points["N"] = np.array([point[1] for point in all_points])
	pd_all_points["chi2"] = np.array([point[2] for point in all_points])
	
	# cal point_sigma
	min_chi2 = pd_all_points["chi2"].min()
	pd_all_points["sigma"] = np.array(convert_delta_chi2_to_sigma(pd_all_points["chi2"] - min_chi2, dof=2))
	
	# cal main, error --------------------------------------------------
	min_main_idx = pd_all_points["sigma"].idxmin()
	
	# 조건: point_sigma <= 1
	filtered_all_points = pd_all_points[pd_all_points["sigma"] <= 1.]
	
	# T,N의 최대값과 최소값 찾기
	max_T = filtered_all_points["T"].max()
	min_T = filtered_all_points["T"].min()	
	max_N = filtered_all_points["N"].max()
	min_N = filtered_all_points["N"].min()
		
	# 해당 행에서 'T'와 'N' 열의 값을 가져옴
	result_quadtree_analyzer["T"] = [pd_all_points.loc[min_main_idx, "T"]]
	main_T = result_quadtree_analyzer.loc[0, "T"]
	result_quadtree_analyzer["T_p_SD"] = np.array(abs(max_T-main_T))
	result_quadtree_analyzer["T_m_SD"] = np.array(abs(min_T-main_T))
	
	result_quadtree_analyzer["N"] = [pd_all_points.loc[min_main_idx, "N"]]
	main_N = result_quadtree_analyzer.loc[0, "N"]
	result_quadtree_analyzer["N_p_SD"] = np.array(abs(max_N-main_N))
	result_quadtree_analyzer["N_m_SD"] = np.array(abs(min_N-main_N))
	#-------------------------------------------------------------------
	
	# print("*"*100)
	# print("result_quadtree_analyzer")
	# print(result_quadtree_analyzer)
	# print(type(result_quadtree_analyzer), len(result_quadtree_analyzer))
	
	return pd_points, pd_all_points, rectangle_points, result_quadtree_analyzer
	
