import numpy as np

import matplotlib
import matplotlib as mpl
import matplotlib.pyplot as plt

import tkinter as tk
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk

import matplotlib.lines as mlines
import matplotlib.patches as mpatches
from matplotlib.legend_handler import HandlerBase

from topsegi.variable import *
from topsegi.data import * 

#=======================================================================
# [ Plot setting ]
matplotlib.use("TkAgg")  # Set backend to TkAgg
mpl.rcParams['axes.labelsize'] = 18   # Axis label size
mpl.rcParams['xtick.labelsize'] = 16  # x-axis tick label size
mpl.rcParams['ytick.labelsize'] = 16  # y-axis tick label size
mpl.rcParams['legend.fontsize'] = 16  # Legend font size
mpl.rcParams['axes.titlesize'] = 15   # Title font size
#=======================================================================
# { SYSTEM : Plotting using only fig in the backend }
def show_plot_in_tkinter(fig, close_on_exit=True):
	
	root = tk.Tk()
	root.wm_title("Figure")
	root.protocol("WM_DELETE_WINDOW", root.quit if close_on_exit else None)
	
	canvas = FigureCanvasTkAgg(fig, master=root)
	canvas.draw()
	canvas.get_tk_widget().pack(side=tk.TOP, fill=tk.BOTH, expand=1)
	
	toolbar = NavigationToolbar2Tk(canvas, root)
	toolbar.update()
	toolbar.pack(side=tk.TOP, fill=tk.X)    
	
	root.mainloop()
	
	if close_on_exit:
		root.destroy()
#=======================================================================
def plot_save(fig, name_plot):
	
	plt.figure(fig.number) # 반환된 fig 객체를 다시 활성화하여 표시
	
	path_base = str(get_path_save_output()) + "/"
	path_save = path_base + name_plot
	
	print("\u2714 Save Plot : ", path_save)
	print("\n")
	
	plt.savefig(path_save, dpi=600, bbox_inches='tight')
#=======================================================================
def plot_TIPS(name_file, TIPS, tag_plot="off"):
	
	fig, ax = plt.subplots(constrained_layout=True)
	
	ax.plot(TIPS["T"], np.log10(TIPS["Q"]), linestyle = "-", color = "black", label = r"$\mathrm {Q}$")
	ax.plot(TIPS["T"], np.log10(get_astronomer_convention()*TIPS["Q"]), linestyle = "--", color = "red", label = rf"$\mathrm{{({get_str_astronomer_convention()})Q}}$")
	
	ax.set_xlabel(r"$\mathrm {T[K]}$")
	ax.set_ylabel(r"$\mathrm {log_{10}(Q)}$")
	
	ax.set_title(
		f"\u2726 File : {name_file}\n"
		f"\u2726 Structure : "
		fr"$\mathrm{{{get_molecule_structure()[get_mol_num()][0]}}}$"
		f", {get_symmetrical_properties()[get_molecule_structure()[get_mol_num()][3][0]]}",
		loc='left'
	)	
	
	ax.legend()
	ax.grid(True)
	#fig.tight_layout()
	#plt.show()
#-----------------------------------------------------------------------
	if tag_plot=="off":
		name_plot = str(get_molecule_structure()[get_mol_num()][1]) + "_" + \
		get_symmetrical_properties()[get_molecule_structure()[get_mol_num()][3][0]] + "_TIPS.pdf"
	else:
		name_plot = tag_plot + "_" + str(get_molecule_structure()[get_mol_num()][1]) + "_" + \
		get_symmetrical_properties()[get_molecule_structure()[get_mol_num()][3][0]] + "_TIPS.pdf"
	
	plot_save(fig, name_plot)
	
	return fig
#=======================================================================	
def plot_RB(name_file, RB, tag_plot="off"):
	
	fig, ax = plt.subplots(constrained_layout=True)
	
	Branch_P = RB[RB["Branch"] == "P"].copy()
	Branch_Q = RB[RB["Branch"] == "Q"].copy()
	Branch_R = RB[RB["Branch"] == "R"].copy()
	
	if not Branch_P.empty:
		ax.plot(Branch_P["J_l"], Branch_P["E_l"], color = "black", linestyle='-' ,linewidth=5, alpha=0.3, label = r"$\mathrm {P \;\; Branch}$")
	if not Branch_Q.empty:
		ax.plot(Branch_Q["J_l"], Branch_Q["E_l"], color = "red"  , linestyle='--',linewidth=3, alpha=0.6, label = r"$\mathrm {Q \;\; Branch}$")
	if not Branch_R.empty:
		ax.plot(Branch_R["J_l"], Branch_R["E_l"], color = "blue" , linestyle=':' ,linewidth=1, alpha=1.0, label = r"$\mathrm {R \;\; Branch}$")
	
	ax.set_xlabel(r"$\mathrm {J_{l}}$")
	ax.set_ylabel(r"$\mathrm {E_{l}[cm^{-1}]}$")

	ax.set_title(
		f"\u2726 File : {name_file}\n"
		f"\u2726 Structure : "
		fr"$\mathrm{{{get_molecule_structure()[get_mol_num()][0]}}}$",
		loc='left'
	)

	ax.legend()
	ax.grid(True)
	#fig.tight_layout()
#-----------------------------------------------------------------------
	if tag_plot=="off":
		name_plot = str(get_molecule_structure()[get_mol_num()][1]) + "_RB.pdf"
	else:
		name_plot = tag_plot + "_" + str(get_molecule_structure()[get_mol_num()][1]) + "_RB.pdf"
	
	plot_save(fig, name_plot)
	
	return fig

def plot_theo(list_data, T_list, tag_plot="off"):
	
	list_linestyle = [
	'-',  # Solid line
	'--', # Dashed line
	':',  # Dotted line
	'-.'  # Dash-dot line
	]
	
	# check plot
	if get_interface() == "c":
		print("\u2714 Check Plot")
		print("\n")
		
	fig, ax = plt.subplots(constrained_layout=True)		
	
	if len(list_data) <= len(list_linestyle):
	
		for i in range(len(list_data)):
			ax.plot(list_data[i]["J_l"], list_data[i]["log10(N_N_l)"],
					color="black",
					linestyle = list_linestyle[i],
					label = rf"$\mathrm{{T[K]={T_list[i]}}}$"
					)
					
	elif len(list_data) > len(list_linestyle):
		
		for i in range(len(list_data)):
			ax.plot(list_data[i]["J_l"], list_data[i]["log10(N_N_l)"],
					label = rf"$\mathrm{{T[K]={T_list[i]}}}$"
					)		

	ax.set_xlabel(r"$\mathrm {J_{l}}$")
	ax.set_ylabel(r"$\mathrm {log_{10} (N/N_{l})}$")

	ax.set_title(
		f"\u2726 Structure : "
		fr"$\mathrm{{{get_molecule_structure()[get_mol_num()][0]}}}$"
		f", {get_symmetrical_properties()[get_molecule_structure()[get_mol_num()][3][0]]}",
		loc='left'
	)
					
	ax.legend(loc='upper left')
	ax.grid(True)

	# TEST x축, y축 범위 설정 minkyu try
	fig.axes[0].set_xlim(0, 50)  # x축 범위
	fig.axes[0].set_ylim(0, 18) # y축 범위
#-----------------------------------------------------------------------
	if tag_plot=="off":
		name_plot = str(get_molecule_structure()[get_mol_num()][1]) + "_" + \
					get_symmetrical_properties()[get_molecule_structure()[get_mol_num()][3][0]] + "_theo.pdf"
	else:
		name_plot = tag_plot + "_" + str(get_molecule_structure()[get_mol_num()][1]) + "_" + \
					get_symmetrical_properties()[get_molecule_structure()[get_mol_num()][3][0]] + "_theo.pdf"
	
	plot_save(fig, name_plot)
	
	return fig

def plot_show_theo(fig1, fig2, fig3, close_on_exit=True):
	root = tk.Tk()
	root.wm_title("THEORETICAL DATA")
	if close_on_exit:
		root.protocol("WM_DELETE_WINDOW", root.quit)
	
	# grid 레이아웃 설정
	root.columnconfigure(0, weight=1)
	root.columnconfigure(1, weight=1)
	root.columnconfigure(2, weight=1)
	root.rowconfigure(0, weight=1)
	
	# fig1 캔버스 생성 (1행 1열)
	frame1 = tk.Frame(root)  # 테두리 제거 (bd=0, relief="flat" 기본값)
	frame1.grid(row=0, column=0, sticky="nsew")
	canvas1 = FigureCanvasTkAgg(fig1, master=frame1)
	canvas1.draw()
	canvas1.get_tk_widget().pack(fill=tk.BOTH, expand=1)
	toolbar1 = NavigationToolbar2Tk(canvas1, frame1)
	toolbar1.update()
	toolbar1.pack(fill=tk.X)
	
	# fig2 캔버스 생성 (1행 2열)
	frame2 = tk.Frame(root)  # 테두리 제거
	frame2.grid(row=0, column=1, sticky="nsew")
	canvas2 = FigureCanvasTkAgg(fig2, master=frame2)
	canvas2.draw()
	canvas2.get_tk_widget().pack(fill=tk.BOTH, expand=1)
	toolbar2 = NavigationToolbar2Tk(canvas2, frame2)
	toolbar2.update()
	toolbar2.pack(fill=tk.X)
	
	# fig3 캔버스 생성 (1행 3열)
	frame3 = tk.Frame(root)  # 테두리 제거
	frame3.grid(row=0, column=2, sticky="nsew")
	canvas3 = FigureCanvasTkAgg(fig3, master=frame3)
	canvas3.draw()
	canvas3.get_tk_widget().pack(fill=tk.BOTH, expand=1)
	toolbar3 = NavigationToolbar2Tk(canvas3, frame3)
	toolbar3.update()
	toolbar3.pack(fill=tk.X)
	
	root.mainloop()
	if close_on_exit:
		root.destroy()

def plot_rotation_diagram(filtered_obs,
							a, a_err,
							b, b_err,
							WLR_x, WLR_y,
							RD_T, RD_T_SD,
							RD_N, RD_N_SD,
							tag_plot="off"):

	# convert input
	Branch_P = filtered_obs[filtered_obs["Branch"] == "P"].copy()	
	Branch_Q = filtered_obs[filtered_obs["Branch"] == "Q"].copy()
	Branch_R = filtered_obs[filtered_obs["Branch"] == "R"].copy()
	
	# 그래프 그리기
	fig, ax = plt.subplots(constrained_layout=True)

	ax.plot(WLR_x, WLR_y, color = "black", linestyle = "-", label=rf"$\mathrm{{WLR(y=ax+b)}}$")  # 피팅된 선
	
	if not Branch_P.empty:
		x_P = np.array(Branch_P["E_l/k_b"])
		y_P = np.array(Branch_P["ln(N_l/g_l)"])
		y_err_lower_P = np.array(Branch_P["ln(N_l/g_l)_SD"])  # y 데이터의 하한 에러
		y_err_upper_P = np.array(Branch_P["ln(N_l/g_l)_SD"])  # y 데이터의 상한 에러
		ax.errorbar(x_P, y_P, yerr=[y_err_lower_P, y_err_upper_P], fmt='^', markerfacecolor='none', color='purple', ecolor = 'purple', markersize=10, capsize=5, label="Branch P")
	
	if not Branch_Q.empty:
		x_Q = np.array(Branch_Q["E_l/k_b"])
		y_Q = np.array(Branch_Q["ln(N_l/g_l)"])
		y_err_lower_Q = np.array(Branch_Q["ln(N_l/g_l)_SD"])  # y 데이터의 하한 에러
		y_err_upper_Q = np.array(Branch_Q["ln(N_l/g_l)_SD"])  # y 데이터의 상한 에러
		ax.errorbar(x_Q, y_Q, yerr=[y_err_lower_Q, y_err_upper_Q], fmt='s', markerfacecolor='none', color='gold', ecolor = 'gold', markersize=10, capsize=5, label="Branch Q")
	
	if not Branch_R.empty:
		x_R = np.array(Branch_R["E_l/k_b"])
		y_R = np.array(Branch_R["ln(N_l/g_l)"])
		y_err_lower_R = np.array(Branch_R["ln(N_l/g_l)_SD"])  # y 데이터의 하한 에러
		y_err_upper_R = np.array(Branch_R["ln(N_l/g_l)_SD"])  # y 데이터의 상한 에러
		ax.errorbar(x_R, y_R, yerr=[y_err_lower_R, y_err_upper_R], fmt='o', markerfacecolor='none', color='blue', ecolor = 'blue', markersize=10, capsize=5, label="Branch R")

	#-------------------------------------------------------------------
	# LaTeX 줄바꿈을 Python 문법으로 처리
	# convert_float_with_error_to_latex
	round_n = 2
	lines = [
	r"$\mathrm {\diamond a} = $" + convert_float_with_error_to_latex(a, [a_err], round_n),
	r"$\mathrm {\diamond b} = $" + convert_float_with_error_to_latex(b, [b_err], round_n), 
	r"$\mathrm {\diamond T[K]} = $" + convert_float_with_error_to_latex(RD_T, [RD_T_SD], round_n),
	r"$\mathrm {\diamond N[cm^{-2}]} = $" + convert_float_with_error_to_latex(RD_N, [RD_N_SD], round_n)
	]
	latex_text = "\n".join(lines)  # 줄바꿈 처리
	
	# 좌하단 텍스트 추가
	ax.text(
	0.03, 0.03,  # 그래프 내부 좌하단 좌표 (0.02, 0.02)
	latex_text,  # 표시할 텍스트
	fontsize=12,  # 글자 크기
	linespacing=1.2,  # 줄 간 간격 (기본값은 1.0)
	transform=ax.transAxes,  # 축 좌표계를 기준으로 위치 지정
	ha="left", va="bottom",  # 텍스트 정렬: 왼쪽 아래 기준
	bbox=dict(
	facecolor="white",  # 배경 색상
	alpha=0.7,          # 투명도 (0: 완전 투명, 1: 불투명)
	edgecolor="gray",   # 테두리 색상
	boxstyle="round,pad=0.3"  # 상자 스타일 (모서리를 둥글게)
	)
	)	
	
	ax.set_xlabel(r"$\mathrm {E_{l}/k_{b}[K]}$")
	ax.set_ylabel(r"$\mathrm {ln(N_{l}/g_{l})}$")
	ax.set_title(
		f"\u2726 Analysis Tool : Rotation Diagram \n"
		#f"\u2726 File : {get_obs_data_name()}\n"
		f"\u2726 Structure : "
		fr"$\mathrm{{{get_molecule_structure()[get_mol_num()][0]}}}$"
		f", {get_symmetrical_properties()[get_molecule_structure()[get_mol_num()][3][0]]}",
		loc='left'
	)	
		
	ax.legend()
	ax.grid(True)

#-----------------------------------------------------------------------
	if tag_plot=="off":
		name_plot = str(get_molecule_structure()[get_mol_num()][1]) + "_" + \
					get_symmetrical_properties()[get_molecule_structure()[get_mol_num()][3][0]] + "_RD.pdf"
	else:
		name_plot = tag_plot + "_" + str(get_molecule_structure()[get_mol_num()][1]) + "_" + \
					get_symmetrical_properties()[get_molecule_structure()[get_mol_num()][3][0]] + "_RD.pdf"
	
	plot_save(fig, name_plot)

	return fig

def format_contour_coord(x, y, X, Y, Z):
	"""
	x, y 위치에서 Z 값을 포함하여 좌표 문자열을 반환합니다.
	LaTeX 형식으로 표시됩니다.
	"""
	
	# str, intention(in)	
	X_axis_name = "T"
	Y_axis_name = "N"
	Z_axis_name = "Sigma"
	
	if x < X[0, 0] or x > X[0, -1] or y < Y[0, 0] or y > Y[-1, 0]:
		return f'X={x:.2f}, Y={y:.2f}, Z=Out of bounds'
	
	i = np.clip(np.abs(Y[:, 0] - y).argmin(), 0, Y.shape[0] - 1)
	j = np.clip(np.abs(X[0, :] - x).argmin(), 0, X.shape[1] - 1)
	Z_value = Z[i, j]
	
	formatted_string = f'{X_axis_name}={x:.4e}, {Y_axis_name}={y:.4e}, {Z_axis_name}={Z_value:.4e}'
	
	return formatted_string

def plot_roughly_contour(X, Y, Z, RD_T, RD_T_SD, RD_N, RD_N_SD, min_X, min_Y, user_contour_levels=10):

	fig, ax = plt.subplots(constrained_layout=True)
	#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	# inf 해치 추가
	# **inf 값이 있는 부분에만 해칭 적용**
	#inf_mask = np.full_like(Z, np.nan)  # NaN으로 채운 배열 생성
	#inf_mask[np.isinf(Z)] = 1  # inf 값이 있는 부분만 1로 설정
	inf_mask = np.full_like(Z, 1)  # NaN으로 채운 배열 생성
	
	# NaN 값을 무시하고 inf 값이 있는 곳에만 해칭 적용
	ax.contourf(X, Y, inf_mask, colors='none', hatches=['x'*3])
	#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++	
	
	contour = ax.contour(X, Y, Z, levels=user_contour_levels, colors='black')  # 선으로 된 등고선

	# 색으로 채워진 등고선
	contourf = ax.contourf(X, Y, Z, levels=user_contour_levels, cmap='Greys')
	ax.clabel(contour, inline=True, fontsize=12, fmt='%.2f', inline_spacing=7)
	cbar = plt.colorbar(contourf, ax=ax, label=r"$\sigma$")

	# This_Work
	ax.scatter(min_X, min_Y, marker='*', color='red', s=150, label=r"$\mathrm {This \; Work}$")

	# Rotation diagrams
	ax.scatter(RD_T, RD_N, marker='*', color='blue', s=150, label=r"$\mathrm {Rotation \; Diagrams}$")
	# 에러바 추가
	ax.errorbar(RD_T, RD_N, xerr=RD_T_SD, yerr=RD_N_SD, fmt='none', ecolor='blue', capsize=5)

	ax.set_xlabel(r"$\mathrm {T[K]}$")
	ax.set_ylabel(r"$\mathrm {N[cm^{-2}]}$")
	ax.set_title(
		f"\u2726 Analysis Tool : Roughly Grid Test ({len(Z)}x{len(Z)}) \n"
		f"\u2726 Structure : "
		fr"$\mathrm{{{get_molecule_structure()[get_mol_num()][0]}}}$"
		f", {get_symmetrical_properties()[get_molecule_structure()[get_mol_num()][3][0]]}",
		loc='left', pad=25
	)
	ax.legend(loc='upper right')
	#ax.legend(loc='best')
	
	ax.format_coord = lambda x, y: format_contour_coord(x, y, X, Y, Z)
	
	return fig

def plot_initial_lims(fig):
    initial_xlims = [axis.get_xlim() for axis in fig.axes]
    initial_ylims = [axis.get_ylim() for axis in fig.axes]
    return initial_xlims, initial_ylims
	
def plot_contour(X, Y, Z_sigma, RD_T, RD_T_SD, RD_N, RD_N_SD, result_quadtree_analyzer, user_contour_levels, tag_plot="off"):
	
	fig, ax = plt.subplots(constrained_layout=True)
	
	#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	# inf 해치 추가
	# **inf 값이 있는 부분에만 해칭 적용**
	#inf_mask = np.full_like(Z, np.nan)  # NaN으로 채운 배열 생성
	#inf_mask[np.isinf(Z)] = 1  # inf 값이 있는 부분만 1로 설정
	inf_mask = np.full_like(Z_sigma, 1)  # NaN으로 채운 배열 생성
	
	# NaN 값을 무시하고 inf 값이 있는 곳에만 해칭 적용
	ax.contourf(X, Y, inf_mask, colors='none', hatches=['x'*3])
	#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++	
		
	contour = ax.contour(X, Y, Z_sigma, levels=user_contour_levels, colors='black')  # 선으로 된 등고선

	# 색으로 채워진 등고선
	contourf = ax.contourf(X, Y, Z_sigma, levels=user_contour_levels, cmap='Greys')
	ax.clabel(contour, inline=True, fontsize=12, fmt='%.2f', inline_spacing=7)
	cbar = plt.colorbar(contourf, ax=ax, label=r"$\sigma$")

	# This_Work
	ax.scatter(result_quadtree_analyzer.loc[0, "T"], result_quadtree_analyzer.loc[0, "N"], marker='*', color='red', s=150, label=r"$\mathrm {This \; Work}$")

	# Rotation diagrams
	ax.scatter(RD_T, RD_N, marker='*', color='blue', s=150, label=r"$\mathrm {Rotation \; Diagram}$")
	# 에러바 추가
	ax.errorbar(RD_T, RD_N, xerr=RD_T_SD, yerr=RD_N_SD, fmt='none', ecolor='blue', capsize=5)
	
	#r"$\mathrm {\diamond N[cm^{-2}]} = $" + convert_float_with_error_to_latex(RD_N, "off", round_n)
	# LaTeX 줄바꿈을 Python 문법으로 처리
	# convert_float_with_error_to_latex
	round_n = 2
	lines = [
	r"$\mathrm {\diamond T^{*}[K]} = $" + convert_float_with_error_to_latex(result_quadtree_analyzer.loc[0, "T"], "off", n=round_n),
	r"$\mathrm {\diamond N^{*}[cm^{-2}]} = $" + convert_float_with_error_to_latex(result_quadtree_analyzer.loc[0, "N"], "off", n=round_n)
	]
	latex_text = "\n".join(lines)  # 줄바꿈 처리
	
	# 좌하단 텍스트 추가
	ax.text(
	0.03, 0.03,  # 그래프 내부 좌하단 좌표 (0.02, 0.02)
	latex_text,  # 표시할 텍스트
	color='red',
	fontsize=12,  # 글자 크기
	linespacing=1.2,  # 줄 간 간격 (기본값은 1.0)
	transform=ax.transAxes,  # 축 좌표계를 기준으로 위치 지정
	ha="left", va="bottom",  # 텍스트 정렬: 왼쪽 아래 기준
	bbox=dict(
	facecolor="white",  # 배경 색상
	alpha=0.7,          # 투명도 (0: 완전 투명, 1: 불투명)
	edgecolor="gray",   # 테두리 색상
	boxstyle="round,pad=0.3"  # 상자 스타일 (모서리를 둥글게)
	)
	, zorder=10)
	
	ax.set_xlabel(r"$\mathrm {T[K]}$")
	ax.set_ylabel(r"$\mathrm {N[cm^{-2}]}$")
	
	ax.set_title(
		#f"\u2726 Analysis Tool : 2D Quadtree \n"
		f"\u2726 Structure : "
		fr"$\mathrm{{{get_molecule_structure()[get_mol_num()][0]}}}$"
		f", {get_symmetrical_properties()[get_molecule_structure()[get_mol_num()][3][0]]}",
		loc='left', pad=25
	)
	
	ax.legend(loc='upper right')
	
	ax.format_coord = lambda x, y: format_contour_coord(x, y, X, Y, Z_sigma)
	initial_xlims, initial_ylims = plot_initial_lims(fig)
	
#-----------------------------------------------------------------------
	if tag_plot=="off":
		name_plot = str(get_molecule_structure()[get_mol_num()][1]) + "_" + \
					get_symmetrical_properties()[get_molecule_structure()[get_mol_num()][3][0]] + "_Quadtree_Analyzer.pdf"
	else:
		name_plot = tag_plot + "_" + str(get_molecule_structure()[get_mol_num()][1]) + "_" + \
					get_symmetrical_properties()[get_molecule_structure()[get_mol_num()][3][0]] + "_Quadtree_Analyzer.pdf"
					
	plot_save(fig, name_plot)
	
	return fig, initial_xlims, initial_ylims

class PatchErrorbar(HandlerBase):
    def create_artists(self, legend, orig_handle, xdescent, ydescent, width, height, fontsize, trans):
        filled_patch, line_top, line_middle, line_bottom = orig_handle

        # 사각형 패치 생성
        patch = mpatches.Rectangle([xdescent, ydescent], width, height, facecolor=filled_patch.get_facecolor(),
                                   edgecolor='none', alpha=filled_patch.get_alpha(), transform=trans)

        # 각 라인의 y 위치 설정
        top_line_y = ydescent + height * 0.95
        middle_line_y = ydescent + height * 0.5
        bottom_line_y = ydescent + height * 0.05

        # 라인 생성
        line_top_artist = mlines.Line2D([xdescent, xdescent + width], [top_line_y, top_line_y],
                                        color=line_top.get_color(), linestyle=line_top.get_linestyle(),
                                        linewidth=line_top.get_linewidth(), transform=trans)
        line_middle_artist = mlines.Line2D([xdescent, xdescent + width], [middle_line_y, middle_line_y],
                                           color=line_middle.get_color(), linestyle=line_middle.get_linestyle(),
                                           linewidth=line_middle.get_linewidth(), transform=trans)
        line_bottom_artist = mlines.Line2D([xdescent, xdescent + width], [bottom_line_y, bottom_line_y],
                                           color=line_bottom.get_color(), linestyle=line_bottom.get_linestyle(),
                                           linewidth=line_bottom.get_linewidth(), transform=trans)

        return [patch, line_top_artist, line_middle_artist, line_bottom_artist]
	
def plot_theo_obs(filtered_obs, list_data, T_list, tag_plot="off"):

	color_list = ["red","red","red", "blue","blue","blue"]
	linestyle_list = ["-","--",":","-","--",":"]
	
	fig, ax = plt.subplots(constrained_layout=True)
	
	for i in range(len(T_list)):
		ax.plot(list_data[i]["J_l"], list_data[i]["log10(N_N_l)"], color=color_list[i], linestyle = linestyle_list[i], label = '_nolegend_')

	# 범례에 사용할 선 및 패치 정의
	line_top0 = mlines.Line2D([], [], color=color_list[0],              linestyle=linestyle_list[1], linewidth=2)
	line_middle0 = mlines.Line2D([], [], color=color_list[0],           linestyle=linestyle_list[0], linewidth=2)
	line_bottom0 = mlines.Line2D([], [], color=color_list[0],           linestyle=linestyle_list[2], linewidth=2)
	filled_patch0 = mpatches.Patch(facecolor=color_list[0], alpha=0.5)
	
	line_top1 = mlines.Line2D([], [], color=color_list[3],              linestyle=linestyle_list[4], linewidth=2)
	line_middle1 = mlines.Line2D([], [], color=color_list[3],           linestyle=linestyle_list[3], linewidth=2)
	line_bottom1 = mlines.Line2D([], [], color=color_list[3],           linestyle=linestyle_list[5], linewidth=2)
	filled_patch1 = mpatches.Patch(facecolor=color_list[3], alpha=0.5)	

	# handles와 labels를 확장하여 추가
	handles = [
	(filled_patch0, line_top0, line_middle0, line_bottom0),
	(filled_patch1, line_top1, line_middle1, line_bottom1)
	]
	
	labels = [
	"$\mathrm{{This \; Work : T[K]=}}$" + convert_float_with_error_to_latex(T_list[0], [abs(T_list[1]-T_list[0]), abs(T_list[2]-T_list[0])], 2),
	"$\mathrm{{RD : T[K]=}}$" + convert_float_with_error_to_latex(T_list[3], [abs(T_list[4]-T_list[3])], 2)
	]
	
	# This work
	ax.fill_between(list_data[0]["J_l"], list_data[0]["log10(N_N_l)"], list_data[1]["log10(N_N_l)"], color=color_list[0], alpha=0.5)
	ax.fill_between(list_data[0]["J_l"], list_data[0]["log10(N_N_l)"], list_data[2]["log10(N_N_l)"], color=color_list[0], alpha=0.5)
	
	# RD
	ax.fill_between(list_data[3]["J_l"], list_data[3]["log10(N_N_l)"], list_data[4]["log10(N_N_l)"], color=color_list[3], alpha=0.5)
	ax.fill_between(list_data[3]["J_l"], list_data[3]["log10(N_N_l)"], list_data[5]["log10(N_N_l)"], color=color_list[3], alpha=0.5)

	Branch_P = filtered_obs[filtered_obs["Branch"] == "P"].copy()	
	Branch_Q = filtered_obs[filtered_obs["Branch"] == "Q"].copy()
	Branch_R = filtered_obs[filtered_obs["Branch"] == "R"].copy()
	
	if not Branch_P.empty:
		x_P = np.array(Branch_P["J_l"])
		y_P = np.array(Branch_P["log10(N/N_l)"])
		y_err_lower_P = np.array(Branch_P["log10(N/N_l)_SD"])  # y 데이터의 하한 에러
		y_err_upper_P = np.array(Branch_P["log10(N/N_l)_SD"])  # y 데이터의 상한 에러
		ax.errorbar(x_P, y_P, yerr=[y_err_lower_P, y_err_upper_P], fmt='^', markerfacecolor='none', color='purple', ecolor = 'purple', markersize=10, capsize=5, label="Branch P")
	
	if not Branch_Q.empty:
		x_Q = np.array(Branch_Q["J_l"])
		y_Q = np.array(Branch_Q["log10(N/N_l)"])
		y_err_lower_Q = np.array(Branch_Q["log10(N/N_l)_SD"])  # y 데이터의 하한 에러
		y_err_upper_Q = np.array(Branch_Q["log10(N/N_l)_SD"])  # y 데이터의 상한 에러
		ax.errorbar(x_Q, y_Q, yerr=[y_err_lower_Q, y_err_upper_Q], fmt='s', markerfacecolor='none', color='gold', ecolor = 'gold', markersize=10, capsize=5, label="Branch Q")
	
	if not Branch_R.empty:
		x_R = np.array(Branch_R["J_l"])
		y_R = np.array(Branch_R["log10(N/N_l)"])
		y_err_lower_R = np.array(Branch_R["log10(N/N_l)_SD"])  # y 데이터의 하한 에러
		y_err_upper_R = np.array(Branch_R["log10(N/N_l)_SD"])  # y 데이터의 상한 에러
		ax.errorbar(x_R, y_R, yerr=[y_err_lower_R, y_err_upper_R], fmt='o', markerfacecolor='none', color='blue', ecolor = 'blue', markersize=10, capsize=5, label="Branch R")
		
	ax.set_xlabel(r"$\mathrm {J_{l}}$")
	ax.set_ylabel(r"$\mathrm {log_{10} (N/N_{l})}$")
	
	ax.set_title(
		f"\u2726 Structure : "
		fr"$\mathrm{{{get_molecule_structure()[get_mol_num()][0]}}}$"
		f", {get_symmetrical_properties()[get_molecule_structure()[get_mol_num()][3][0]]}",
		loc='left'
	)	
	ax.legend(loc='upper left')
	
	# 자동으로 추가된 라인 포함
	auto_handles, auto_labels = ax.get_legend_handles_labels()
	
	# 기존 수동 handles와 labels 병합
	all_handles = handles + auto_handles
	all_labels = labels + auto_labels
	
	# 범례 업데이트
	ax.legend(all_handles, all_labels, loc='upper left', handler_map={tuple: PatchErrorbar()}, frameon=False)		
	
	ax.grid(True)
	
	# TEST x축, y축 범위 설정 # minkyu try
	fig.axes[0].set_xlim(0, 30)  # x축 범위
	fig.axes[0].set_ylim(0, 5) # y축 범위
	
#-----------------------------------------------------------------------
	if tag_plot=="off":
		name_plot = str(get_molecule_structure()[get_mol_num()][1]) + "_" + \
					get_symmetrical_properties()[get_molecule_structure()[get_mol_num()][3][0]] + "_theo_obs.pdf"
	else:
		name_plot = tag_plot + "_" + str(get_molecule_structure()[get_mol_num()][1]) + "_" + \
					get_symmetrical_properties()[get_molecule_structure()[get_mol_num()][3][0]] + "_theo_obs.pdf"
					
	plot_save(fig, name_plot)
		
	return fig
