# [ Imported Python packages ]
import os
import numpy as np
import pandas as pd

from topsegi.variable import *
from topsegi.control import *

def create_folder(path_base, name_folder, tag_folder):
	 
	# Create folder path
	path_target = os.path.join(path_base, name_folder)
	
	# Check for duplicate names and append a number to create a unique name
	counter = 1
	while os.path.exists(path_target):
		path_relative = os.path.relpath(path_target)
		print(f"\u21E2 The [{tag_folder}] '{path_relative}' already exists.")
		path_target = os.path.join(path_base, f"{name_folder}_({counter})")
		counter += 1
	
	# Create folder with a unique folder path
	os.makedirs(path_target, exist_ok=True)
	
	# Get the relative path of the created folder
	path_relative = os.path.relpath(path_target)
	print(f"\u2714 Location for saving [{tag_folder}] : {path_relative}")
	print("\n")
	
	# set_path_save_output
	set_path_save_output(path_relative)

def data_sort_and_drop_RB(RB): #minkyu
	
	if get_molecule_structure()[get_mol_num()][3][0] == 0: # symmetric(even) = 0
		# print(instance_system.molecule_structure[instance_system.mol_num][2][0], type(instance_system.molecule_structure[instance_system.mol_num][2][0]))
		# J_l 중복된 행 제거 후, J_l 열 기준으로 오름차순 정렬하여 새로운 데이터프레임 생성
		sort_and_drop_RB = RB.drop_duplicates(subset='J_l').sort_values(by='J_l').reset_index(drop=True).copy()		
		sort_and_drop_RB = sort_and_drop_RB[sort_and_drop_RB['J_l'] % 2 == 0].reset_index(drop=True).copy()
		
	elif get_molecule_structure()[get_mol_num()][3][0] == 1: # symmetric(odd) = 1
		# print(instance_system.molecule_structure[instance_system.mol_num][2][0], type(instance_system.molecule_structure[instance_system.mol_num][2][0]))
		# J_l 중복된 행 제거 후, J_l 열 기준으로 오름차순 정렬하여 새로운 데이터프레임 생성
		sort_and_drop_RB = RB.drop_duplicates(subset='J_l').sort_values(by='J_l').reset_index(drop=True).copy()
		sort_and_drop_RB = sort_and_drop_RB[sort_and_drop_RB['J_l'] % 2 == 1].reset_index(drop=True).copy()
	
	elif get_molecule_structure()[get_mol_num()][3][0] == 2: # asymmetric = 2
		# print(instance_system.molecule_structure[instance_system.mol_num][2][0], type(instance_system.molecule_structure[instance_system.mol_num][2][0]))
		# J_l 중복된 행 제거 후, J_l 열 기준으로 오름차순 정렬하여 새로운 데이터프레임 생성
		sort_and_drop_RB = RB.drop_duplicates(subset='J_l').sort_values(by='J_l').reset_index(drop=True).copy()
		
	return sort_and_drop_RB

def data_save(data, name_data):
	
	path_base = str(get_path_save_output()) + "/"
	path_save = path_base + name_data
	
	print("\u2714 Save Output data : ", path_save)

	data.to_csv(path_save, index=False)
	
def data_filter(RB):
	
	# get_data
	obs_data = pd.read_csv(get_path_obs(), sep=",")
	
	#---
	
	# 1. 'J_l'과 'Branch'의 조합이 일치하는 행을 찾기 위해 inner merge 수행
	matched_rows = obs_data.merge(RB[['J_l', 'Branch']], on=['J_l', 'Branch'], how='inner').copy()
	# print("matched_rows")
	# print(matched_rows)
	
	# 3. 'J_l'과 'Branch'의 조합을 기준으로 매칭되지 않는 행을 찾기
	non_matching_rows_obs = obs_data[~obs_data[['J_l', 'Branch']].apply(tuple, axis=1).isin(matched_rows[['J_l', 'Branch']].apply(tuple, axis=1))].copy()
	# print("non_matching_rows_obs")
	# print(non_matching_rows_obs)

	####
	
	filtered_obs = matched_rows.copy()
	
	# 1. 빈 리스트 생성 (for문을 사용하여 순차적으로 행을 추가하기 위해)
	filtered_theo_rows = []
	
	# 2. matched_rows의 각 ['J_l', 'Branch'] 조합을 순서대로 검색
	for _, row in matched_rows.iterrows():
	    # 'J_l'과 'Branch' 값이 일치하는 행을 RB에서 찾기
	    matching_row = RB[
	        (RB['J_l'] == row['J_l']) &
	        (RB['Branch'] == row['Branch'])
	    ].copy()
	    
	    # 찾은 행을 filtered_theo_rows 리스트에 추가
	    filtered_theo_rows.append(matching_row)
	
	# 3. filtered_theo_rows 리스트를 데이터프레임으로 결합
	filtered_theo = pd.concat(filtered_theo_rows, ignore_index=True)	
	
	#=======================================================
	# filtered_obs에 filtered_theo의  g_l, E_l/k_b 추가
	filtered_obs["g_l"] = filtered_theo["g_l"]
	filtered_obs["E_l/k_b"] = filtered_theo["E_l/k_b"]
	#=======================================================
	# 항 추가
	filtered_obs["ln(N_l/g_l)"] = np.log(filtered_obs["N_l"]/filtered_obs["g_l"])
	filtered_obs["ln(N_l/g_l)_SD"] = filtered_obs["N_l_SD"]/filtered_obs["N_l"]			
	#=======================================================				
	
	# 4. 삭제된 행이 있는지 확인하고 출력
	if not non_matching_rows_obs.empty:
		
		message_segmentation("OBSERVATIONAL DATA")
		
		print("\u21E2 Observational data name : ", get_name_obs_data())
		print("\n")
		
		print("\u21E2 Observational data")
		print(obs_data)
		print("\n")
		
		print("\u21E2 filtered observational data")
		print(filtered_obs)
		print("\n")
		
		print("\u21E2 Observed data ignored : no matching theoretical data")
		print(non_matching_rows_obs)
		print("\n")
		
		print("\u21E2 filtered theoretical data")
		print(filtered_theo)
		print("\n")
		
	else:
		
		message_segmentation("OBSERVATIONAL DATA")

		print("\u21E2 Observational data name : ", get_name_obs_data())
		print("\n")

		print("\u21E2 filtered observational data")
		print(filtered_obs)
		print("\n")
		
		print("\u21E2 filtered theoretical data")
		print(filtered_theo)
		print("\n")
	
	return filtered_theo, filtered_obs

def data_precision(value_main, list_error, n):
	
	# Step 1 : get exponent_main
	if value_main != 0:
		abs_value_main = np.abs(value_main)
		log_value_main = np.log10(abs_value_main)
		exponent_main = int(np.floor(log_value_main))
	else:
		exponent_main = 0
	
	# Step 2 : scaled_main
	divided_main = value_main / (10 ** exponent_main)
	scaled_main = round(divided_main, n)
	
	# Step 3 : scaled_error
	list_scaled_error = []
	
	if list_error == "off":
		pass
	
	else:
		for i in range(len(list_error)):
			divided_error = list_error[i] / (10 ** exponent_main)
			scaled_error = round(divided_error, n)
			list_scaled_error.append(scaled_error)
			
		#print(exponent_main, scaled_main, list_scaled_error)
	
	return (exponent_main, scaled_main, list_scaled_error)
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++	
def convert_float_with_error_to_latex(value_main, list_error, n):
	
	(exponent_main, scaled_main, list_scaled_error) = data_precision(value_main, list_error, n)
	
	if list_error == "off":
		# Create the LaTeX string with \mathrm
		scaled_main = f"{scaled_main:.{n}f}"
		result = rf"$\mathrm{{{scaled_main} \times 10^{{{exponent_main}}}}}$"	
	
	elif len(list_error) == 1:
		# Create the LaTeX string with \mathrm
		scaled_main = f"{scaled_main:.{n}f}"
		list_scaled_error[0] = f"{list_scaled_error[0]:.{n}f}" 
		result = rf"$\mathrm{{({scaled_main} \pm {list_scaled_error[0]}) \times 10^{{{exponent_main}}}}}$"
	
	elif len(list_error) == 2:
		# Create the LaTeX string with \mathrm
		scaled_main = f"{scaled_main:.{n}f}"
		list_scaled_error[0] = f"{list_scaled_error[0]:.{n}f}"
		list_scaled_error[1] = f"{list_scaled_error[1]:.{n}f}"				
		result = rf"$\mathrm{{({scaled_main} ^{{+{list_scaled_error[0]}}}_{{-{list_scaled_error[1]}}}) \times 10^{{{exponent_main}}}}}$"
		
	return result
			
