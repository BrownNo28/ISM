from ATLAS.control import *
from ATLAS.calculation import *
from ATLAS.data import *
from ATLAS.plot import *

from ATLAS.variable import * #TSET

from matplotlib.patches import Rectangle

user_tag_data="This_Work"
#user_tag_data="HITRAN"

#=======================================================================	
print("╔═════════════════════════════════════════════════════════════╗")
print("║                        START PROGRAM                        ║")
print("╚═════════════════════════════════════════════════════════════╝")
print("\n")
#=======================================================================
# [ Running ]

# { enter_interface }
message_segmentation("INTERFACE")
enter_interface()

# { create_output_data_folder }
message_segmentation("OUTPUT FOLDER")
(
name_output_folder
) = enter_name_folder(
					path_base = get_path_base_output(),
					tag_folder = "OUTPUT FOLDER",
					name_interface_i_col = "output_name"
					)
create_folder(path_base = get_path_base_output(),
			name_folder = name_output_folder,
			tag_folder = "OUTPUT FOLDER"
			)

# { enter_theo }
message_segmentation("THEORETICAL DATA")
(
path_TIPS, path_RB
) = enter_theo()

# { enter_TIPS }
message_segmentation("TIPS")
(name_file_TIPS, TIPS) = enter_TIPS(path_TIPS)
fig_TIPS = plot_TIPS(name_file_TIPS, TIPS, tag_plot=user_tag_data)
#show_plot_in_tkinter(fig_TIPS)

# { enter_rotational_branches }
message_segmentation("ROTATIONAL BRANCHES")
(name_file_RB, RB) = enter_RB(path_RB)
RB = cal_RB(RB)
fig_RB = plot_RB(name_file_RB, RB, tag_plot=user_tag_data)
#show_plot_in_tkinter(fig_RB)

# { plot_theo }
message_segmentation("PLOT THEORETICAL DATA")
sort_and_drop_RB = data_sort_and_drop_RB(RB)
print(sort_and_drop_RB)
T_list = [100, 300, 500, 1000] #minkyu try
list_cal_theo_data = []
for i in range(len(T_list)):
	cal_theo_data = cal_theo(sort_and_drop_RB, TIPS, T_list[i], tag_data=user_tag_data)
	list_cal_theo_data.append(cal_theo_data)
fig_theo = plot_theo(list_cal_theo_data, T_list, tag_plot=user_tag_data)
#show_plot_in_tkinter(fig_theo)

if get_interface() == "c":
	plot_show_theo(fig_TIPS, fig_RB, fig_theo)
	
#=======================================================================
#$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
#$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
#$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
#$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$

# { enter_obs }
enter_path_obs()

# { data_filter }
filtered_theo, filtered_obs = data_filter(RB)
(a, a_err,
b, b_err,
WLR_x, WLR_y,
RD_T, RD_T_SD,
RD_N, RD_N_SD) = cal_rotation_diagram(filtered_obs, TIPS)

# { rotation_diagram }
fig_RD = plot_rotation_diagram(
filtered_obs,
a, a_err,
b, b_err,
WLR_x, WLR_y,
RD_T, RD_T_SD,
RD_N, RD_N_SD,
tag_plot=user_tag_data)
#show_plot_in_tkinter(fig_RD)

#$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$

# Initial Parameter Space
RD_n_times = 3. # user        #minkyu try
axis_grid = 50 # 축 당 그리드 수  #minkyu try

(
T_start, T_end,
N_start, N_end
) = cal_parameter_range(
x_m_evaluator = RD_T - RD_n_times*RD_T_SD,
x_p_evaluator = RD_T + RD_n_times*RD_T_SD, 
y_m_evaluator = RD_N - RD_n_times*RD_N_SD,
y_p_evaluator = RD_N + RD_n_times*RD_N_SD
)

X, Y, Z_chi2, Z_sigma, min_X, min_Y, min_Z_chi2 = cal_data_background_contour(T_start, T_end, N_start, N_end, axis_grid, TIPS, filtered_theo, filtered_obs)

fig_roughly_contour = plot_roughly_contour(X, Y, Z_sigma, RD_T, RD_T_SD, RD_N, RD_N_SD, min_X, min_Y, user_contour_levels=10)
plot_save(fig_roughly_contour, "roughly_contour_test.pdf")
#show_plot_in_tkinter(fig_roughly_contour)

#$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$

RD_n_times = 1.2 #test #minkyu try
#RD_n_times = 15       #minkyu try

range_X = abs(min_X - RD_T) + RD_n_times*RD_T_SD
range_Y = abs(min_Y - RD_N) + RD_n_times*RD_N_SD

(
T_start, T_end,
N_start, N_end
) = cal_parameter_range(
x_m_evaluator = min_X - range_X,
x_p_evaluator = min_X + range_X, 
y_m_evaluator = min_Y - range_Y,
y_p_evaluator = min_Y + range_Y
)

X, Y, Z_chi2, Z_sigma, min_X, min_Y, min_Z_chi2 = cal_data_background_contour(T_start, T_end, N_start, N_end, axis_grid, TIPS, filtered_theo, filtered_obs)

user_threshold = 3.     #minkyu try
input_user_depth = 5-2    #minkyu try
input_add_depth = 4-2     #minkyu try

# user_threshold = 3.-2      #minkyu try
# input_user_depth = 5+1       #minkyu try
# input_add_depth = 4      #minkyu try

pd_points, pd_all_points, rectangle_points, result_quadtree_analyzer = quadtree_analyzer(TIPS, filtered_theo, filtered_obs, T_start, T_end, N_start, N_end, min_Z_chi2, user_threshold, input_user_depth, input_add_depth)

# test
fig_quadtree_analyzer, initial_xlims, initial_ylims = plot_contour(X, Y, Z_sigma, RD_T, RD_T_SD, RD_N, RD_N_SD, result_quadtree_analyzer, user_contour_levels=10, tag_plot=user_tag_data)
#show_plot_in_tkinter(fig_quadtree_analyzer)

for point in rectangle_points:
    x_min, x_max, y_min, y_max = point  # 각 노드 범위 포함
    width = x_max - x_min  # x축 길이
    height = y_max - y_min  # y축 길이
    rect = Rectangle((x_min, y_min), width, height, fill=False, edgecolor='gray', linewidth=1)
    fig_quadtree_analyzer.axes[0].add_patch(rect)  # ax_obs에 Rectangle 추가

# fig_quadtree_analyzer.axes[0].scatter(pd_all_points["T"], pd_all_points["N"], marker=".", c='purple',alpha=0.5, label="Grid Points")
# fig_quadtree_analyzer.axes[0].scatter(pd_points["T"], pd_points["N"], marker=",", c='green',alpha=0.5, label = "Distinction Points")
# fig_quadtree_analyzer.axes[0].scatter(result_quadtree_analyzer.loc[0, "T"], result_quadtree_analyzer.loc[0, "N"], marker='*', color='orange', s=100, label = "Result Point")
fig_quadtree_analyzer.axes[0].scatter(pd_all_points["T"], pd_all_points["N"], marker=".", c='purple',alpha=0.5)
fig_quadtree_analyzer.axes[0].scatter(pd_points["T"], pd_points["N"], marker=",", c='green',alpha=0.5)
fig_quadtree_analyzer.axes[0].scatter(result_quadtree_analyzer.loc[0, "T"], result_quadtree_analyzer.loc[0, "N"], marker='*', color='red', s=100)
fig_quadtree_analyzer.axes[0].legend(loc='upper right')
plot_save(fig_quadtree_analyzer, "point_test.pdf")
#show_plot_in_tkinter(fig_quadtree_analyzer)

#$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
T_obs_list = [
result_quadtree_analyzer.loc[0, "T"],
result_quadtree_analyzer.loc[0, "T"]+result_quadtree_analyzer.loc[0,"T_p_SD"],
result_quadtree_analyzer.loc[0, "T"]-result_quadtree_analyzer.loc[0,"T_m_SD"],
RD_T,
RD_T+RD_T_SD,
RD_T-RD_T_SD
] #minkyu try
# print("T_obs_list : ", T_obs_list)
# print("filtered_obs")
# print(filtered_obs)
list_cal_theo_obs_data = []
for i in range(len(T_obs_list)):
	cal_theo_obs_data = cal_theo(sort_and_drop_RB, TIPS, T_obs_list[i], tag_data=user_tag_data)
	list_cal_theo_obs_data.append(cal_theo_obs_data)

fig_theo_obs = plot_theo_obs(filtered_obs, list_cal_theo_obs_data, T_obs_list, tag_plot=user_tag_data)
#show_plot_in_tkinter(fig_theo_obs)

print("result_quadtree_analyzer")
# 모든 값을 지수 표기법으로 변환
result_quadtree_analyzer_formatted = result_quadtree_analyzer.applymap(lambda x: f"{x:.4e}")
print(result_quadtree_analyzer_formatted)
#=======================================================================
print("\n")
print("╔═════════════════════════════════════════════════════════════╗")
print("║                        END PROGRAM                          ║")
print("╚═════════════════════════════════════════════════════════════╝")
#=======================================================================
