#!/usr/bin/bash

# 첫 번째 인수를 AGE 변수에 저장
Input_Card_Path="$1"

# AGE 변수가 설정되지 않았을 경우 메시지 출력 후 종료
if [ -z "$Input_Card_Path" ]; then
  echo "How to use: ./run.sh [Input_Card_Path]"
  exit 1
fi

# 다른 입력값 설정
Interface="i"
Confirm="1"

# 파이썬 스크립트에 입력값 전달
python3 main.py << EOF
$Interface
$Input_Card_Path
$Confirm
EOF
