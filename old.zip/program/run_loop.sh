#!/usr/bin/bash

# 사용자에게 파일 이름 입력받기
read -p "Enter the command file name: " filename

# 입력받은 파일이 존재하는지 확인
if [[ ! -f "$filename" ]]; then
    echo "Error: File '$filename' not found."
    exit 1
fi

# 파일에서 명령어 한 줄씩 읽어 실행
while IFS= read -r line || [[ -n "$line" ]]; do
    echo "Executing: $line"
    eval "$line"
done < "$filename"
