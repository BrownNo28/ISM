#=======================================================================
n_separator = 60

def get_n_separator():
	return n_separator
#=======================================================================
# { interface ; c = Command Line Interface, i = Input Card }
interface = None

def get_interface():
	return interface

def set_interface(value):
	global interface
	interface = value
#=======================================================================
# { path_input_card : File path of the input card }
path_input_card = None

def get_path_input_card():
	return path_input_card

def set_path_input_card(value):
	global path_input_card
	path_input_card = value
#=======================================================================
# { data_input_card : pandas.DataFrame type}
data_input_card = None

def get_data_input_card():
	return data_input_card

def set_data_input_card(value):
	global data_input_card
	data_input_card = value
#=======================================================================
path_base_output = "../output"

def get_path_base_output():
	return path_base_output
#=======================================================================	
path_save_output = None

def get_path_save_output():
	return path_save_output

def set_path_save_output(value):
	global path_save_output
	path_save_output = value
#=======================================================================
# { molecule_structure }
# molecule_structure[0~9][0] : molecule structure
# molecule_structure[0~9][1] : symmetric or asymmetric
# molecule_structure[0~9][2][0] ;
#  0 = symmetric(even)
#  1 = symmetric(odd)
#  2 = asymmetric
# 10 = undefined

molecule_structure = [
[r"(0). \; C_{2} H_{2}",       "(0).H-12C≡12C-H", "symmetric",  [10] , [1./4., 3./4.],     ["1/4", "3/4"]     ],
[r"(1). \; ^{13}C C H_{2}",    "(1).H-13C≡12C-H", "asymmetric", [2] ],
[r"(2). \; C_{2} H D",         "(2).D-12C≡12C-H", "asymmetric", [2] ], 
[r"(3). \; ^{13}C_{2} H_{2}",  "(3).H-13C≡13C-H", "symmetric",  [10] , [10./16., 6./16.],  ["10/16", "6/16"]  ],
[r"(4). \; D ^{12}C ^{13}C H", "(4).D-12C≡13C-H", "asymmetric", [2] ],
[r"(5). \; D ^{13}C ^{12}C H", "(5).D-13C≡12C-H", "asymmetric", [2] ],
[r"(6). \; C_{2} D_{2}",       "(6).D-12C≡12C-D", "symmetric",  [10] , [6./9., 3./9.],     ["6/9", "3/9"]     ],
[r"(7). \; ^{13}C_{2} H D",    "(7).D-13C≡13C-H", "asymmetric", [2] ],
[r"(8). \; ^{13}C C D_{2}",    "(8).D-13C≡12C-D", "asymmetric", [2] ],
[r"(9). \; ^{13}C_{2} D_{2}",  "(9).D-13C≡13C-D", "symmetric",  [10] , [15./36., 21./36.], ["15/36", "21/36"] ]
]
def get_molecule_structure():
	return molecule_structure

def set_molecule_structure(value):
	global molecule_structure
	molecule_structure = value
#=======================================================================	
# { mol_num : Number of the molecular structure, int type}
mol_num = None

def get_mol_num():
	return mol_num

def set_mol_num(value):
	global mol_num
	mol_num = value
#=======================================================================
# { symmetrical_properties }
symmetrical_properties = [
						"symmetric(even)",
						"symmetric(odd)",
						"asymmetric"
						]
def get_symmetrical_properties():
	return symmetrical_properties
#=======================================================================
astronomer_convention = None

def get_astronomer_convention():
	return astronomer_convention
	
def set_astronomer_convention(value):
	global astronomer_convention
	astronomer_convention = value
#=======================================================================
str_astronomer_convention = None

def get_str_astronomer_convention():
	return str_astronomer_convention
	
str_astronomer_convention = None
def set_str_astronomer_convention(value):
	global str_astronomer_convention
	str_astronomer_convention = value
#=======================================================================
min_TIPS = None

def get_min_TIPS():
	return min_TIPS
	
def set_min_TIPS(value):
	global min_TIPS
	min_TIPS = value
#=======================================================================
max_TIPS = None

def get_max_TIPS():
	return max_TIPS
	
def set_max_TIPS(value):
	global max_TIPS
	max_TIPS = value
#=======================================================================
path_obs = None

def get_path_obs():
	return path_obs
	
def set_path_obs(value):
	global path_obs
	path_obs = value
#=======================================================================
name_obs_data = None

def get_name_obs_data():
	return name_obs_data
	
def set_name_obs_data(value):
	global name_obs_data
	name_obs_data = value
#=======================================================================
