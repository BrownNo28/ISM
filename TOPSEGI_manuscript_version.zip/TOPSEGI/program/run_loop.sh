#!/usr/bin/bash

Command_Path="$1"

if [ -z "$Command_Path" ]; then
  echo "How to use: ./run_loop.sh <command.txt>"
  exit 1
fi


while IFS= read -r line || [[ -n "$line" ]]; do
    echo "Executing: $line"
    eval "$line"
done < "$Command_Path"
