# [ Imported Python packages ]
from dataclasses import dataclass

@dataclass(frozen=False)
class mol_sys:
	# { symmetrical_properties }
	symmetrical_properties = [
							"symmetric(even)",
							"symmetric(odd)",
							"asymmetric"
							]
	# { plot_theo }
	T_list = [100, 300, 500, 1000]

@dataclass(frozen=False)
class mol_sym:
	molecule_sym = ["C2H2", "HCN", "HNC"]
#=======================================================================
#=======================================================================
@dataclass(frozen=False)
class mol_C2H2:
	# { path_TIPS_array } # repro_add
	path_TIPS_array = [
	"../input/theoretical_data/TIPS/HITRAN_TIPS_2021_vol0.csv",
	"../input/theoretical_data/TIPS/HITRAN_TIPS_2021_vol1.csv",
	"../input/theoretical_data/TIPS/HITRAN_TIPS_2021_vol2.csv",
	"../input/theoretical_data/TIPS/This_Work_TIPS_vol3.csv",
	"../input/theoretical_data/TIPS/This_Work_TIPS_vol4.csv",
	"../input/theoretical_data/TIPS/This_Work_TIPS_vol5.csv",
	"../input/theoretical_data/TIPS/This_Work_TIPS_vol6.csv",
	"../input/theoretical_data/TIPS/This_Work_TIPS_vol7.csv",
	"../input/theoretical_data/TIPS/This_Work_TIPS_vol8.csv",
	"../input/theoretical_data/TIPS/This_Work_TIPS_vol9.csv"
	]
	
	# { path_rotational_branches_array } # repro_add
	path_rotational_branches_array = [
	"../input/theoretical_data/Rotational_Branches/HITRAN_Rotational_Branches_vol0.csv",
	"../input/theoretical_data/Rotational_Branches/HITRAN_Rotational_Branches_vol1.csv",
	"../input/theoretical_data/Rotational_Branches/HITRAN_Rotational_Branches_vol2.csv",
	"../input/theoretical_data/Rotational_Branches/This_Work_Rotational_Branches_vol3.csv",
	"../input/theoretical_data/Rotational_Branches/This_Work_Rotational_Branches_vol4.csv",
	"../input/theoretical_data/Rotational_Branches/This_Work_Rotational_Branches_vol5.csv",
	"../input/theoretical_data/Rotational_Branches/This_Work_Rotational_Branches_vol6.csv",
	"../input/theoretical_data/Rotational_Branches/This_Work_Rotational_Branches_vol7.csv",
	"../input/theoretical_data/Rotational_Branches/This_Work_Rotational_Branches_vol8.csv",
	"../input/theoretical_data/Rotational_Branches/This_Work_Rotational_Branches_vol9.csv"
	]
		
	molecule_structure = [
	["C_{2} H_{2}",       "H-12C≡12C-H", "symmetric",  [10] , [1./4., 3./4.],     ["1/4", "3/4"]     ],
	["^{13}C C H_{2}",    "H-13C≡12C-H", "asymmetric", [2] ],
	["C_{2} H D",         "D-12C≡12C-H", "asymmetric", [2] ], 
	["^{13}C_{2} H_{2}",  "H-13C≡13C-H", "symmetric",  [10] , [10./16., 6./16.],  ["10/16", "6/16"]  ],
	["D ^{12}C ^{13}C H", "D-12C≡13C-H", "asymmetric", [2] ],
	["D ^{13}C ^{12}C H", "D-13C≡12C-H", "asymmetric", [2] ],
	["C_{2} D_{2}",       "D-12C≡12C-D", "symmetric",  [10] , [6./9., 3./9.],     ["6/9", "3/9"]     ],
	["^{13}C_{2} H D",    "D-13C≡13C-H", "asymmetric", [2] ],
	["^{13}C C D_{2}",    "D-13C≡12C-D", "asymmetric", [2] ],
	["^{13}C_{2} D_{2}",  "D-13C≡13C-D", "symmetric",  [10] , [15./36., 21./36.], ["15/36", "21/36"] ]
	]
	
@dataclass(frozen=False)
class mol_HCN:
	# { path_TIPS_array } # repro_add
	path_TIPS_array = [
	"../input/theoretical_data/TIPS/HITRAN_TIPS_2021_H12C14N.csv",
	"../input/theoretical_data/TIPS/HITRAN_TIPS_2021_H12C14N.csv",
	"../input/theoretical_data/TIPS/HITRAN_TIPS_2021_H13C14N.csv"	
	]
	
	# { path_rotational_branches_array } # repro_add
	path_rotational_branches_array = [
	"../input/theoretical_data/Rotational_Branches/RB_HITRAN_TABLE4.csv",
	"../input/theoretical_data/Rotational_Branches/RB_HITRAN_TABLE4.csv",
	"../input/theoretical_data/Rotational_Branches/RB_HITRAN_TABLE3.csv"
	]
	
	molecule_structure = [
	["H^{12}C^{14}N [Q]",    "H12C14N [Q]", "asymmetric", [2] ],
	["H^{12}C^{14}N [R]",    "H12C14N [R]", "asymmetric", [2] ],
	["H^{13}C^{14}N [R]",    "H13C14N [R]", "asymmetric", [2] ]
	]

@dataclass(frozen=False)
class mol_HNC:
	# { path_TIPS_array } # repro_add
	path_TIPS_array = [
	"../input/theoretical_data/TIPS/ExoMol_H14N12C_line.csv",
	"../input/theoretical_data/TIPS/ExoMol_H14N12C_line.csv",
	"../input/theoretical_data/TIPS/ExoMol_H14N12C_line.csv"
	]
	
	# { path_rotational_branches_array } # repro_add
	path_rotational_branches_array = [
	"../input/theoretical_data/Rotational_Branches/RB_HNC_filtered_P.csv",
	"../input/theoretical_data/Rotational_Branches/RB_HNC_filtered_Q.csv",
	"../input/theoretical_data/Rotational_Branches/RB_HNC_filtered_R.csv"
	]
	
	molecule_structure = [
	["H^{14}N^{12}C [P]",    "H14N12C [P]", "asymmetric", [2] ],
	["H^{14}N^{12}C [Q]",    "H14N12C [Q]", "asymmetric", [2] ],
	["H^{14}N^{12}C [R]",    "H14N12C [R]", "asymmetric", [2] ]
	]
class gv:
	astronomer_convention: float
	str_astronomer_convention: str

	min_TIPS: float
	max_TIPS: float
	
	path_obs: str
	name_obs_data: str
#=======================================================================
#=======================================================================

@dataclass(frozen=True)
class ConstantConfig:
	h: float = 6.62607015e-34 #[J*s] # Planck constant
	c: float = 2.99792458e8 #[m/s] # Speed of light
	kb: float = 1.380649e-23 #[J*K^-1] # Boltzmann constant

@dataclass(frozen=True)
class SystemConfig:
	path_base_output: str
	n_separator: int
	user_threshold: int
	input_user_depth: int 
	input_add_depth: int 
	round_n: int
	roughly_RD_n_times: float 
	axis_grid: int 
	cal_RD_n_times: float 
	grid_switch: bool 
	img_extension_switch: str 
	user_tag_data: str

@dataclass(frozen=True)
class InputConfig:
	sym_num: int
	name_output_folder: str 
	mol_num: int 
	parity: int 
	obs_switch: int 
	path_obs_user: str 
