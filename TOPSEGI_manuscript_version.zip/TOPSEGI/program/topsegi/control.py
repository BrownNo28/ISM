# [ Imported Python packages ]
import os
import sys
import pandas as pd
import configparser
import click
from topsegi.variable import *
#=======================================================================

def get_system_config(card_file):
	
	parser = configparser.ConfigParser()
	parser.read(card_file)

	path_base_output = parser.get('SYSTEM', 'path_base_output')
	n_separator = parser.getint('SYSTEM', 'n_separator')   
	user_threshold = parser.getint('SYSTEM', 'user_threshold')
	input_user_depth = parser.getint('SYSTEM', 'input_user_depth')
	input_add_depth = parser.getint('SYSTEM', 'input_add_depth') 
	round_n = parser.getint('SYSTEM', 'round_n')
	roughly_RD_n_times = parser.getfloat('SYSTEM', 'roughly_RD_n_times')
	axis_grid = parser.getint('SYSTEM', 'axis_grid')
	cal_RD_n_times = parser.getfloat('SYSTEM', 'cal_RD_n_times')
	grid_switch = parser.getboolean('SYSTEM', 'grid_switch') 
	img_extension_switch = parser.get('SYSTEM', 'img_extension_switch')
	user_tag_data = parser.get('SYSTEM', 'user_tag_data') 
	
	return SystemConfig(
	path_base_output = path_base_output,
	n_separator = n_separator,
	user_threshold = user_threshold,
	input_user_depth = input_user_depth,
	input_add_depth = input_add_depth,
	round_n = round_n,
	roughly_RD_n_times = roughly_RD_n_times,
	axis_grid = axis_grid,
	cal_RD_n_times = cal_RD_n_times,
	grid_switch = grid_switch,
	img_extension_switch = img_extension_switch,
	user_tag_data = user_tag_data
	)

def get_input_from_file(card_file):

	# <csv>
	user_input_data = pd.read_csv(card_file, sep=",", header=None, index_col=0)
	
	sym_num = int(user_input_data.loc["sym_num", 1])
	name_output_folder = str(user_input_data.loc["output_name", 1])
	mol_num = int(user_input_data.loc["mol_num", 1])
	parity = int(user_input_data.loc["symmetrical_properties", 1])
	obs_switch = int(user_input_data.loc["obs_switch", 1])
	path_obs_user = str(user_input_data.loc["obs_path", 1])   
	
	return InputConfig(
	sym_num = sym_num,
	name_output_folder = name_output_folder,
	mol_num = mol_num,
	parity = parity,
	obs_switch = obs_switch,
	path_obs_user = path_obs_user 
	)

def get_input_from_interactive(sys_cfg): 
	
    message_segmentation("OUTPUT FOLDER", sys_cfg.n_separator)
    
    name_output_folder = click.prompt("name_output_folder", type=str)
    path_save_output = create_folder(
					path_base = sys_cfg.path_base_output,
					name_folder = name_output_folder,
					tag_folder = "OUTPUT FOLDER"
					)
					
    # { enter_theo }
    message_segmentation("THEORETICAL DATA", n_separator)
    # repro_add
    for i in range(len(molecule_structure)):
        print("\u2605 " + molecule_structure[i][1] + ", " + molecule_structure[i][2])
    print("\n")

    return InputConfig(name_output_folder=name_output_folder)
#=======================================================================
def enter_theo():
	
	# global astronomer_convention
	# global str_astronomer_convention
#-----------------------------------------------------------------------
	if molecule_structure[mol_num][3][0] == 0: # symmetric(even) = 0
		gv.astronomer_convention = molecule_structure[mol_num][4][0] 
		gv.str_astronomer_convention = molecule_structure[mol_num][5][0] 
		
	elif molecule_structure[mol_num][3][0] == 1: # symmetric(odd) = 1
		gv.astronomer_convention = molecule_structure[mol_num][4][1] 
		gv.str_astronomer_convention = molecule_structure[mol_num][5][1] 
	
	elif molecule_structure[mol_num][3][0] == 2: # asymmetric = 2
		gv.astronomer_convention = 1. 
		gv.str_astronomer_convention = "1" 

	# [ Set Astronomer convention ]
	print("\u2756 Set Astronomer convention \u2756")
	print(f"\u21E2 Astronomer convention : {gv.str_astronomer_convention}")
	print("\n")

#-----------------------------------------------------------------------	
	# [ set theoretical data path ]
	print("\u2756 Set theoretical data path \u2756")

	# TIPS_file_path
	path_TIPS = os.path.relpath(path_TIPS_array[mol_num])
	print("\u21E2 TIPS(Total Internal Partition Sums) data file path")
	print(path_TIPS)
	
	# rotational_branches_file_path
	path_RB = os.path.relpath(path_rotational_branches_array[mol_num])
	print("\u21E2 Rotational_Branches data file path")
	print(path_RB)
	print("\n")

	return path_TIPS, path_RB
#=======================================================================
def enter_TIPS(path_file): #def_ok
	
	# TIPS
	
	# file_type : csv
	# file_sep : ,
	# file_columns : [T, Q], T=[K], Q=[], header!=None
	
	# get_file_name
	name_file = os.path.basename(path_file)
	
	# get_data
	TIPS = pd.read_csv(path_file, sep=",")
	
	# get TIPS min and max
	gv.min_TIPS = TIPS["Q"].min()
	gv.max_TIPS = TIPS["Q"].max()
	
	# print data
	print("\u2714 Check Table : ", path_file)
	print(TIPS)
	print("\n")
	
	return name_file, TIPS
#=======================================================================
def enter_RB(path_file): #def_ok
	
	# RB = rotational_branches
	
	# get_name_file
	name_file = os.path.basename(path_file)
	
	# get_data
	RB = pd.read_csv(path_file, sep=",")

	# print data
	print("\u2714 Check Table : ", path_file)
	print(RB)
	print("\n")
	
	return name_file, RB
#=======================================================================
# def enter_path_obs(): # repro_1
def enter_path_obs(obs_switch): # repro_2 
		
	if int(obs_switch) == 0:
		print("╔═════════════════════════════════════════════════════════════╗")
		print("║                        END PROGRAM                          ║")
		print("╚═════════════════════════════════════════════════════════════╝")
		sys.exit()
	
	elif int(obs_switch) == 1:

		# path_relative = os.path.relpath(path_obs) # repro_1
		path_relative = os.path.relpath(path_obs_user) # repro_2 
		print(f"\u21E2 Observational data file path : {path_relative}")
		
		gv.path_obs = path_relative
		gv.name_obs_data = os.path.basename(path_relative)
#=======================================================================

def message_segmentation(message, n_separator):
	
	print("\u276F" * n_separator + "\n")
	print(f"\u2726 {message} \u2726" +"\n")
