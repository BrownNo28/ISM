# [ Imported Python packages ]
import os
import numpy as np
import pandas as pd

from topsegi.variable import *
from topsegi.control import *
#=======================================================================
def create_folder(path_base, name_folder, tag_folder):
	 
	# Create folder path
	path_target = os.path.join(path_base, name_folder)
	
	# Check for duplicate names and append a number to create a unique name
	counter = 1
	while os.path.exists(path_target):
		path_relative = os.path.relpath(path_target)
		print(f"\u21E2 The [{tag_folder}] '{path_relative}' already exists.")
		path_target = os.path.join(path_base, f"{name_folder}_({counter})")
		counter += 1
	
	# Create folder with a unique folder path
	os.makedirs(path_target, exist_ok=True)
	os.makedirs(path_target + "/cal", exist_ok=True) # repro_add
	os.makedirs(path_target + "/img", exist_ok=True) # repro_add
	
	# Get the relative path of the created folder
	path_relative = os.path.relpath(path_target)
	print(f"\u2714 Location for saving [{tag_folder}] : {path_relative}")
	print("\n")
	
	# # set_path_save_output #repro_1
	# set_path_save_output(path_relative) #repro_1
	path_save_output = path_relative # repro_add
	return path_save_output # repro_add
#=======================================================================
def data_sort_and_drop_RB(RB): #minkyu
	
	if molecule_structure[mol_num][3][0] == 0: # symmetric(even) = 0
		sort_and_drop_RB = RB.drop_duplicates(subset='J_l').sort_values(by='J_l').reset_index(drop=True).copy()		
		sort_and_drop_RB = sort_and_drop_RB[sort_and_drop_RB['J_l'] % 2 == 0].reset_index(drop=True).copy()
		
	elif molecule_structure[mol_num][3][0] == 1: # symmetric(odd) = 1
		sort_and_drop_RB = RB.drop_duplicates(subset='J_l').sort_values(by='J_l').reset_index(drop=True).copy()
		sort_and_drop_RB = sort_and_drop_RB[sort_and_drop_RB['J_l'] % 2 == 1].reset_index(drop=True).copy()
	
	elif molecule_structure[mol_num][3][0] == 2: # asymmetric = 2
		sort_and_drop_RB = RB.drop_duplicates(subset='J_l').sort_values(by='J_l').reset_index(drop=True).copy()
		
	return sort_and_drop_RB
#=======================================================================
def data_save(data, name_data):
	
	# path_base = str(get_path_save_output()) + "/" # repro_1
	path_base = str(path_save_output) # repro_2
	
	# path_save = path_base + name_data # repro_1
	path_save = path_base + "/cal/" + name_data # repro_2
	
	print("\u2714 Save Output data : ", path_save)

	data.to_csv(path_save, index=False)
#=======================================================================
def data_filter(RB):
	
	# get_data
	# obs_data = pd.read_csv(get_path_obs(), sep=",") # repro_1
	obs_data = pd.read_csv(gv.path_obs, sep=",") # repro_2
	
	matched_rows = obs_data.merge(RB[['J_l', 'Branch']], on=['J_l', 'Branch'], how='inner').copy()
	
	non_matching_rows_obs = obs_data[~obs_data[['J_l', 'Branch']].apply(tuple, axis=1).isin(matched_rows[['J_l', 'Branch']].apply(tuple, axis=1))].copy()
	
	####
	filtered_obs = matched_rows.copy()
	filtered_theo_rows = []
	
	for _, row in matched_rows.iterrows():
		
	    matching_row = RB[
	        (RB['J_l'] == row['J_l']) &
	        (RB['Branch'] == row['Branch'])
	    ].copy()
	    
	    filtered_theo_rows.append(matching_row)
	
	filtered_theo = pd.concat(filtered_theo_rows, ignore_index=True)	
	
	#=======================================================
	filtered_obs["g_l"] = filtered_theo["g_l"]
	filtered_obs["E_l/k_b"] = filtered_theo["E_l/k_b"]
	#=======================================================
	filtered_obs["ln(N_l/g_l)"] = np.log(filtered_obs["N_l"]/filtered_obs["g_l"])
	filtered_obs["ln(N_l/g_l)_SD"] = filtered_obs["N_l_SD"]/filtered_obs["N_l"]			
	#=======================================================				

	if not non_matching_rows_obs.empty:
		
		message_segmentation("OBSERVATIONAL DATA", n_separator)
		
		print("\u21E2 Observational data name : ", gv.name_obs_data) # repro_2
		print("\n")
		
		print("\u21E2 Observational data")
		print(obs_data)
		print("\n")
		
		print("\u21E2 filtered observational data")
		print(filtered_obs)
		print("\n")
		
		print("\u21E2 Observed data ignored : no matching theoretical data")
		print(non_matching_rows_obs)
		print("\n")
		
		print("\u21E2 filtered theoretical data")
		print(filtered_theo)
		print("\n")
		
	else:
		
		message_segmentation("OBSERVATIONAL DATA", n_separator)

		print("\u21E2 Observational data name : ", gv.name_obs_data) # repro_2
		print("\n")

		print("\u21E2 filtered observational data")
		print(filtered_obs)
		print("\n")
		
		print("\u21E2 filtered theoretical data")
		print(filtered_theo)
		print("\n")
	
	return filtered_theo, filtered_obs
#=======================================================================
def data_precision(value_main, list_error, n):
	
	# Step 1 : get exponent_main
	if value_main != 0:
		abs_value_main = np.abs(value_main)
		log_value_main = np.log10(abs_value_main)
		exponent_main = int(np.floor(log_value_main))
	else:
		exponent_main = 0
	
	# Step 2 : scaled_main
	divided_main = value_main / (10 ** exponent_main)
	scaled_main = round(divided_main, n)
	
	# Step 3 : scaled_error
	list_scaled_error = []
	
	if list_error == "off":
		pass
	
	else:
		for i in range(len(list_error)):
			divided_error = list_error[i] / (10 ** exponent_main)
			scaled_error = round(divided_error, n)
			list_scaled_error.append(scaled_error)
	
	return (exponent_main, scaled_main, list_scaled_error)
#=======================================================================
def convert_float_with_error_to_latex(value_main, list_error, n):
	
	(exponent_main, scaled_main, list_scaled_error) = data_precision(value_main, list_error, n)
	
	if list_error == "off":
		# Create the LaTeX string with \mathrm
		scaled_main = f"{scaled_main:.{n}f}"
		result = rf"$\mathrm{{{scaled_main} \times 10^{{{exponent_main}}}}}$"	
	
	elif len(list_error) == 1:
		# Create the LaTeX string with \mathrm
		scaled_main = f"{scaled_main:.{n}f}"
		list_scaled_error[0] = f"{list_scaled_error[0]:.{n}f}" 
		result = rf"$\mathrm{{({scaled_main} \pm {list_scaled_error[0]}) \times 10^{{{exponent_main}}}}}$"
	
	elif len(list_error) == 2:
		# Create the LaTeX string with \mathrm
		scaled_main = f"{scaled_main:.{n}f}"
		list_scaled_error[0] = f"{list_scaled_error[0]:.{n}f}"
		list_scaled_error[1] = f"{list_scaled_error[1]:.{n}f}"				
		result = rf"$\mathrm{{({scaled_main} ^{{+{list_scaled_error[0]}}}_{{-{list_scaled_error[1]}}}) \times 10^{{{exponent_main}}}}}$"
		
	return result
#=======================================================================
