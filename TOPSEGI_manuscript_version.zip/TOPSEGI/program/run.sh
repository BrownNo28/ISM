#!/usr/bin/bash

Input_Card_Path="$1"

if [ -z "$Input_Card_Path" ]; then
  echo "How to use: ./run.sh <path_to_input_card>"
  exit 1
fi

Interface="i"

python3 main.py << EOF
$Interface
$Input_Card_Path
EOF
