# [ Imported Python packages ]
import builtins
import sys
import click
import gc
import numpy as np
from topsegi.variable import *
from topsegi.control import *
from topsegi.calculation import *
from topsegi.data import *
from topsegi.plot import *
from matplotlib.patches import Rectangle

# user_contour_levels : UCL
UCL = np.linspace(0.0, 36.0, 37)

def run():
	#===============================================================
	# <mol_sys>
	builtins.symmetrical_properties = mol_sys.symmetrical_properties
	builtins.T_list = mol_sys.T_list	
	
	# <con>
	con = ConstantConfig()
	builtins.h = con.h
	builtins.c = con.c
	builtins.kb = con.kb

	# <sys_cfg>	
	builtins.path_base_output = sys_cfg.path_base_output
	builtins.n_separator = sys_cfg.n_separator
	builtins.user_threshold = sys_cfg.user_threshold
	builtins.input_user_depth = sys_cfg.input_user_depth
	builtins.input_add_depth = sys_cfg.input_add_depth
	builtins.round_n = sys_cfg.round_n
	builtins.roughly_RD_n_times = sys_cfg.roughly_RD_n_times
	builtins.axis_grid = sys_cfg.axis_grid
	builtins.cal_RD_n_times = sys_cfg.cal_RD_n_times
	builtins.grid_switch = sys_cfg.grid_switch
	builtins.img_extension_switch = sys_cfg.img_extension_switch
	builtins.user_tag_data = sys_cfg.user_tag_data
	
	# <mol>
	builtins.molecule_sym = mol_sym.molecule_sym

	# <CASE>
	# mol_HCN, <END>
	if interface == "i":

		# <inp_cfg>
		builtins.sym_num = inp_cfg.sym_num
		builtins.name_output_folder = inp_cfg.name_output_folder
		builtins.mol_num = inp_cfg.mol_num
		builtins.parity = inp_cfg.parity
		builtins.obs_switch = inp_cfg.obs_switch
		builtins.path_obs_user = inp_cfg.path_obs_user

		if molecule_sym[sym_num] == "C2H2":
			mol_name = mol_C2H2()
		elif molecule_sym[sym_num] == "HCN":
			mol_name = mol_HCN()
		elif molecule_sym[sym_num] == "HNC":
			mol_name = mol_HNC()
			
		builtins.mol_name = mol_name

		builtins.path_TIPS_array = mol_name.path_TIPS_array
		builtins.path_rotational_branches_array = mol_name.path_rotational_branches_array
		builtins.molecule_structure = mol_name.molecule_structure
		molecule_structure[mol_num][3][0] = parity
	
	builtins.gv = gv
	
	#===============================================================
	#===============================================================
	# [ Running ]
	
	# { create_output_data_folder }
	message_segmentation("OUTPUT FOLDER", n_separator)
	
	print(f"\u21E2 The location where the [OUTPUT FOLDER] will be created : {path_base_output}")
	print("\n")
	
	if interface == "c":
		builtins.name_output_folder = click.prompt("\u21E8 Enter the name for the [OUTPUT FOLDER] storage folder to be created", prompt_suffix=" : ")
		print("\n")
	
	builtins.path_save_output = create_folder( 
						path_base = path_base_output, #repro_2
						name_folder = name_output_folder,
						tag_folder = "OUTPUT FOLDER"
						)				
	
	# { enter_theo }
	message_segmentation("THEORETICAL DATA", n_separator)

	for i in range(len(molecule_sym)):
		print("\u2605 ("+str(i)+") " + molecule_sym[i])
	print("\n")
	
	if interface == "c":
		builtins.sym_num = click.prompt(f"\u21E8 Enter the number of the molecule to be calculated [0~{len(molecule_sym) - 1}]", 
		type=click.IntRange(0, len(molecule_sym) - 1), prompt_suffix=" : ")
		print("\n")
		
		if molecule_sym[sym_num] == "C2H2":
			mol_name = mol_C2H2()
		elif molecule_sym[sym_num] == "HCN":
			mol_name = mol_HCN()
		elif molecule_sym[sym_num] == "HNC":
			mol_name = mol_HNC()
				
		builtins.path_TIPS_array = mol_name.path_TIPS_array
		builtins.path_rotational_branches_array = mol_name.path_rotational_branches_array
		builtins.molecule_structure = mol_name.molecule_structure

	# repro_add
	for i in range(len(molecule_structure)):
		print("\u2605 ("+str(i)+") " + molecule_structure[i][1] + ", " + molecule_structure[i][2])
	print("\n")

	if interface == "c":
		builtins.mol_num = click.prompt(f"\u21E8 Enter the number of the molecular structure to be calculated [0~{len(molecule_structure) - 1}]", 
		type=click.IntRange(0, len(molecule_structure) - 1), prompt_suffix=" : ")
		print("\n")
	
	if builtins.molecule_structure[mol_num][2] == "symmetric":
	
		builtins.molecule_structure[mol_num][3][0] = click.prompt(
		"\u21E8 Enter the parity (even = 0, odd = 1)",
		type=click.IntRange(0, 1),
		prompt_suffix=" : "
		)

	(
	path_TIPS, path_RB
	) = enter_theo()
	
	# { enter_TIPS }
	message_segmentation("TIPS", n_separator)
	(name_file_TIPS, TIPS) = enter_TIPS(path_TIPS)
	fig_TIPS = plot_TIPS(name_file_TIPS, TIPS, tag_plot=user_tag_data)
	
	# { enter_rotational_branches }
	message_segmentation("ROTATIONAL BRANCHES", n_separator)
	(name_file_RB, RB) = enter_RB(path_RB)
	RB = cal_RB(RB)
	fig_RB = plot_RB(name_file_RB, RB, tag_plot=user_tag_data)
	
	# { plot_theo }
	message_segmentation("PLOT THEORETICAL DATA", n_separator)
	
	sort_and_drop_RB = data_sort_and_drop_RB(RB)
	print(sort_and_drop_RB)
	
	list_cal_theo_data = []
	for i in range(len(T_list)):
		cal_theo_data = cal_theo(sort_and_drop_RB, TIPS, T_list[i], tag_data=user_tag_data)
		list_cal_theo_data.append(cal_theo_data)
	fig_theo = plot_theo(list_cal_theo_data, T_list, tag_plot=user_tag_data)

	if interface == "c":
		plot_show_theo(fig_TIPS, fig_RB, fig_theo)
	
	#=======================================================================
	#$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
	
	if interface == "c":
		builtins.obs_switch = click.prompt(
			"\u21E8 Do you have observational data? (yes = 1, no = 0)",
			type=click.IntRange(0, 1),
			prompt_suffix=" : "
			)
		print("\n")
		
		if builtins.obs_switch == 1:
			builtins.path_obs_user = click.prompt(
			"\u21E8 Enter the file path of the observational data",
			type=click.Path(exists=True),
			prompt_suffix=" : "
			)
			print("\n")
	
	# { enter_obs }
	enter_path_obs(obs_switch) # repro_2
	
	# { data_filter }
	filtered_theo, filtered_obs = data_filter(RB)
	
	# { rotation_diagram }
	(a, a_err,
	b, b_err,
	WLR_x, WLR_y,
	builtins.RD_T, builtins.RD_T_SD,
	builtins.RD_N, builtins.RD_N_SD) = cal_rotation_diagram(filtered_obs, TIPS)
	
	fig_RD = plot_rotation_diagram(
	filtered_obs,
	a, a_err,
	b, b_err,
	WLR_x, WLR_y,
	RD_T, RD_T_SD,
	RD_N, RD_N_SD,
	tag_plot=user_tag_data)
	
	#$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
	
	# Initial Parameter Space
	(
	T_start, T_end,
	N_start, N_end
	) = cal_parameter_range(
	x_m_evaluator = RD_T - roughly_RD_n_times*RD_T_SD,
	x_p_evaluator = RD_T + roughly_RD_n_times*RD_T_SD, 
	y_m_evaluator = RD_N - roughly_RD_n_times*RD_N_SD,
	y_p_evaluator = RD_N + roughly_RD_n_times*RD_N_SD
	)
	
	X, Y, Z_chi2, Z_sigma, min_X, min_Y, min_Z_chi2 = cal_data_background_contour(T_start, T_end, N_start, N_end, axis_grid, TIPS, filtered_theo, filtered_obs)
	
	fig_roughly_contour = plot_roughly_contour(X, Y, Z_sigma, RD_T, RD_T_SD, RD_N, RD_N_SD, min_X, min_Y, user_contour_levels=UCL)
	plot_save(fig_roughly_contour, "roughly_contour_test" + img_extension_switch)
	if interface == "c":
		show_plot_in_tkinter(fig_roughly_contour)
	
	#$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
	
	range_X = abs(min_X - RD_T) + cal_RD_n_times*RD_T_SD
	range_Y = abs(min_Y - RD_N) + cal_RD_n_times*RD_N_SD
	
	(
	T_start, T_end,
	N_start, N_end
	) = cal_parameter_range(
	x_m_evaluator = min_X - range_X,
	x_p_evaluator = min_X + range_X, 
	y_m_evaluator = min_Y - range_Y,
	y_p_evaluator = min_Y + range_Y
	)
	
	X, Y, Z_chi2, Z_sigma, min_X, min_Y, min_Z_chi2 = cal_data_background_contour(T_start, T_end, N_start, N_end, axis_grid, TIPS, filtered_theo, filtered_obs)
	
	#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	# test
	pd_points, pd_all_points, rectangle_points, result_quadtree_analyzer, min_chi2 = quadtree_analyzer(TIPS, filtered_theo, filtered_obs, T_start, T_end, N_start, N_end, min_Z_chi2, user_threshold, input_user_depth, input_add_depth)
	fig_quadtree_analyzer, initial_xlims, initial_ylims = plot_contour(X, Y, Z_sigma, RD_T, RD_T_SD, RD_N, RD_N_SD, result_quadtree_analyzer, user_contour_levels=UCL, tag_plot=user_tag_data)
	if interface == "c":
		show_plot_in_tkinter(fig_quadtree_analyzer)
	
	#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	# test end >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
	# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	
	for point in rectangle_points:
	    x_min, x_max, y_min, y_max = point
	    width = x_max - x_min 
	    height = y_max - y_min 
	    rect = Rectangle((x_min, y_min), width, height, fill=False, edgecolor='gray', linewidth=1)
	    fig_quadtree_analyzer.axes[0].add_patch(rect).set_zorder(3)
	
	fig_quadtree_analyzer.axes[0].scatter(pd_all_points["T"], pd_all_points["N"], marker=".", c='magenta', alpha=0.5, zorder=4, label="Grid Points")
	fig_quadtree_analyzer.axes[0].scatter(pd_points["T"], pd_points["N"], marker=",", c='green',alpha=0.5, zorder=5, label="Distinction Points")
	fig_quadtree_analyzer.axes[0].legend(loc='upper right', fontsize=10).set_zorder(11)
	plot_save(fig_quadtree_analyzer, "point_test.pdf")
	
	#$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
	
	T_obs_list = [
	result_quadtree_analyzer.loc[0, "chi2_T"],
	result_quadtree_analyzer.loc[0, "chi2_T"]+result_quadtree_analyzer.loc[0,"chi2_T_p_SD"],
	result_quadtree_analyzer.loc[0, "chi2_T"]-result_quadtree_analyzer.loc[0,"chi2_T_m_SD"],
	RD_T,
	RD_T+RD_T_SD,
	RD_T-RD_T_SD
	] 
	
	list_cal_theo_obs_data = []
	for i in range(len(T_obs_list)):
		cal_theo_obs_data = cal_theo(sort_and_drop_RB, TIPS, T_obs_list[i], tag_data=user_tag_data)
		list_cal_theo_obs_data.append(cal_theo_obs_data)
	
	fig_theo_obs = plot_theo_obs(filtered_obs, list_cal_theo_obs_data, T_obs_list, tag_plot=user_tag_data)
	if interface == "c":
		show_plot_in_tkinter(fig_theo_obs)
	
	print("result_quadtree_analyzer")
	#result_quadtree_analyzer_formatted = result_quadtree_analyzer.applymap(lambda x: f"{x:.4e}")
	#result_quadtree_analyzer_formatted = result_quadtree_analyzer.map(lambda x: f"{x:.5e}")
	result_quadtree_analyzer_formatted = pd.concat([
	    result_quadtree_analyzer.iloc[:, :-2].applymap(lambda x: f"{x:.5e}"),
	    result_quadtree_analyzer.iloc[:, -2:].applymap(lambda x: f"{int(x)}")
	], axis=1)		
	print(result_quadtree_analyzer_formatted)
	
	name_result_quadtree_analyzer_formatted_data = user_tag_data+"_"+str(molecule_structure[mol_num][1]) + "_" + \
						str(symmetrical_properties[molecule_structure[mol_num][3][0]]) + "_" +\
						"result_quadtree_analyzer_formatted.csv"
	data_save(result_quadtree_analyzer_formatted, name_result_quadtree_analyzer_formatted_data)	

def main():
	#=======================================================================	
	print("╔═════════════════════════════════════════════════════════════╗")
	print("║                        START PROGRAM                        ║")
	print("╚═════════════════════════════════════════════════════════════╝")
	print("\n")
	#=======================================================================  
	# -------------------------------------------------------------------
	# <system.card>
	str_system_file = "../input/input_card/system.card"
	builtins.sys_cfg = get_system_config(str_system_file)

	# <interface>
	message_segmentation("INTERFACE", sys_cfg.n_separator)
	builtins.interface = click.prompt(
			"\u21E8 Select interface mode \n  [c = Command Line Interface, i = Input Card]",
			type=click.Choice(['c', 'i'], case_sensitive=False), show_choices=False,
			prompt_suffix=" : "
			)
		
	if interface == "c":
		print("\u2714 Starting [Command Line Interface] mode.")
		print("\n")
		run()

	
	# [I모드: 단일 파일]
	elif interface == "i":
		print("\u2714 Starting [Input Card] mode.")
		print("\n")
		
		# <input card>
		# ../input/input_card/input_card.csv
		builtins.path_input_card = click.prompt(
		"\u21E8 Enter the file path of the input card",
		type=click.Path(exists=True),
		prompt_suffix=" : "
		)
		
		builtins.inp_cfg = get_input_from_file(path_input_card)
		print("\u2714 sym_num : ", inp_cfg.sym_num)
		print("\u2714 output_name : ", inp_cfg.name_output_folder)
		print("\u2714 mol_num : ", inp_cfg.mol_num)
		print("\u2714 symmetrical_properties : ", inp_cfg.parity)
		print("\u2714 obs_switch : ", inp_cfg.obs_switch)
		print("\u2714 obs_path : ", inp_cfg.path_obs_user)
		print("\n")
		run()
			
	#=======================================================================
	print("\n")
	print("╔═════════════════════════════════════════════════════════════╗")
	print("║                        END PROGRAM                          ║")
	print("╚═════════════════════════════════════════════════════════════╝")
	#=======================================================================
if __name__ == '__main__':
	main()
